%% bdg_ldos.m  —— Fig.4: 赝朗道能级 + 超导能隙的局域态密度
% 模型: 石墨烯 Dirac 锥 + 赝磁场 B_s (谷 K/K' 反号) + 均匀配对势 Delta
%   正常态: 石墨烯赝朗道能级  E_n = sgn(n) * vF * sqrt(2 hbar e |B| |n|),  n=0 在零能
%   BdG(量子极限, 配对在 LL 基下对角):  E_{n,+/-} = +/- sqrt(E_n^2 + Delta^2)
%   谷 K  : B_tot = B_real + B_s
%   谷 K': B_tot = B_real - B_s   -> 加一个真实外场即可读出赝场 (Fig.4d)
% 注: 这是"单锥 + 均匀 Delta"的量子极限模型, 用于展示能级骨架与谷分辨指纹;
%     完整莫尔 BdG 需在应变 BM 哈密顿量上做, 属后续工作.
% 依赖: base MATLAB (R2016b+)
clear; clc; close all;

%% ---------- 参数 ----------
vF    = 1.0e6;                 % m/s
hbar  = 1.055e-34;  e = 1.602e-19;
Nmax  = 8;                     % LL 序号上限
eta   = 6;                     % Lorentzian 展宽 (meV)
Bs_list = [0 0.5 1 2 4];       % 赝磁场 (T): 对应不同应变梯度
Delta   = 1.5;                 % 配对势 (meV)
B_real  = linspace(0,4,81);    % 真实外场扫描 (T)
Eaxis   = linspace(-300,300,4000);
%% -------------------------

LL = @(B,n) sign(n).*vF.*sqrt(2*hbar*e.*abs(B).*abs(n))/e*1e3;   % J -> meV

figure('Name','Fig.4: pseudo-Landau levels & SC gap','Color','w','Position',[60 40 1100 800]);

% (a) E_n vs n
subplot(2,2,1); hold on;
for Bs = Bs_list(2:end)
    ns = 0:Nmax;
    plot(ns, LL(Bs,ns), 'o-','LineWidth',1.4);
end
xlabel('Landau index n'); ylabel('E_n (meV)'); grid on;
title('(a) pseudo-Landau levels: E_n = +/- hv_F sqrt(2 n b_s)');
legend(arrayfun(@(b) sprintf('B_s = %.1f T',b), Bs_list(2:end), 'UniformOutput',false), ...
       'Location','northwest');

% (b) 正常态 LDOS
subplot(2,2,2); hold on;
for Bs = Bs_list
    plot(Eaxis, norm1(ldos_ll(Eaxis, Bs, Nmax, eta, LL)), 'LineWidth',1.4);
end
xlabel('E (meV)'); ylabel('LDOS (arb.)'); grid on;
title('(b) normal-state LDOS: LL peaks');
legend(arrayfun(@(b) sprintf('B_s = %.1f T',b), Bs_list, 'UniformOutput',false));

% (c) 超导态 BdG LDOS (固定 B_s, 变 Delta)
subplot(2,2,3); hold on;
Bs = 2; Dl_list = [0 0.5 1 1.5 2.5];
for Dl = Dl_list
    plot(Eaxis, norm1(ldos_bdg(Eaxis, Bs, Nmax, eta, LL, Dl)), 'LineWidth',1.4);
end
xlabel('E (meV)'); ylabel('LDOS (arb.)'); grid on;
title(sprintf('(c) BdG LDOS at B_s = %.0f T: gap + LL peaks', Bs));
legend(arrayfun(@(x) sprintf('\\Delta = %.1f meV',x), Dl_list, 'UniformOutput',false));

% (d) 谷劈裂 |E_1^K - E_1^{K'}|
subplot(2,2,4); hold on;
Bs_set = [0 0.5 1 2];
for Bs = Bs_set
    dE = abs(LL(B_real+Bs,1) - LL(B_real-Bs,1));
    plot(B_real, dE, 'LineWidth',1.5);
end
xlabel('real field B (T)'); ylabel('|E_1^K - E_1^{K''}| (meV)'); grid on;
title('(d) valley splitting of n=1 LL vs real field');
legend(arrayfun(@(b) sprintf('B_s = %.1f T',b), Bs_set, 'UniformOutput',false), ...
       'Location','northwest');

figs = findall(0,'Type','figure');  [~,o] = sort([figs.Number]);  figs = figs(o);
save_paper_figs(figs, mfilename);
fprintf('saved %d figures\n', numel(figs));

% ======================= 局部函数 =======================
function d = norm1(d)
    if max(d) > 0, d = d/max(d); end
end

function d = ldos_ll(E, Bs, Nmax, eta, LL)
% 正常态 LDOS: 各 LL 的 Lorentzian 叠加; Bs=0 退化为 Dirac 线性 DOS ~ |E|
    if Bs == 0
        d = abs(E);  return;
    end
    d = zeros(size(E));
    for n = -Nmax:Nmax
        En = LL(Bs,n);
        d  = d + (eta/pi)./((E-En).^2 + eta^2);
    end
end

function d = ldos_bdg(E, Bs, Nmax, eta, LL, Dl)
% BdG LDOS: 每个 LL 劈成 +/- sqrt(E_n^2 + Delta^2)
    d = zeros(size(E));
    for n = -Nmax:Nmax
        Eb = sqrt(LL(Bs,n)^2 + Dl^2);
        d  = d + (eta/pi)./((E-Eb).^2 + eta^2) + (eta/pi)./((E+Eb).^2 + eta^2);
    end
end
