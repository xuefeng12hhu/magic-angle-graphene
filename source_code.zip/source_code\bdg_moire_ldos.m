%% bdg_moire_ldos.m —— Fig.2 (figures/fig4.png) v3
%  相对原版改动:
%   - (a) B_s 范围 [0 0.5 1 2] -> [0 2 5 10] T (覆盖 B_s ~ flat-band-width 物理区),
%         展宽 4 -> 2.5 meV, E 范围 -80..80 -> -180..180; 竖虚线标 ħv√(2eBn)
%   - (b) 粗实线 intervalley + 细深色虚线 intravalley + 灰色点线 B_s=0:
%         两条通道重合本身即结论, 故让套叠可读, 并显式标注重合幅度; 右上角加 log 内嵌
%   - (c) 观测量换成谷谱对比度 C(B_real)=∫|LDOS_K-LDOS_K'|dE/∫LDOS_K dE
%         (原版跟踪 n=1 峰位, 但 33.6√B meV 处并无主导谱峰 -> 观测量选择不当)
%   - (d) 显式打印 inter/intra |diff| (日志), 让残留差距 (来自非配对壳边界态) 透明
clear; clc; close all;
rng(1);

a0=0.246; hbarv=610; w=110; K0=4*pi/(3*a0);
theta=1.05; cphi=7*pi/6; Nsc=3; Nsh=2;
Delta0=1.5; etaN=2.5; etaB=1.2;
BsA=[0 2 5 10]; BsD=[0 0.5 1 1.5 2]; BrC=[0 0.25 0.5 0.75 1 1.25 1.5 2 2.5 3]; BsC=1;
EaxA=linspace(-180,180,2401);   % panel a
EaxB=linspace(-30,30,1201);     % panel b
hbarJ=1.0545718e-34; eC=1.6021766e-19; meVJ=1.6021766e-22;
hvm=hbarv*meVJ*1e-9;

S=moire_setup(Nsh,Nsc,theta,w,hbarv,cphi,K0);
qn=norm(S.G1)/Nsc;
convB=hvm*eC/(hbarJ*qn*1e9)/meVJ;   % meV/T
LL1=hvm*sqrt(2*eC/hbarJ)/meVJ;      % ħv√(2eB) meV/√T
fprintf('Supercell N=%d, Nsh=%d: NPW=%d, single-valley %d-d, BdG %d-d\n',Nsc,Nsh,S.NPW,4*S.NPW,8*S.NPW);
fprintf('Field coupling %.2f meV/T; ħv√(2eB)=%.1f√B meV; λ=%.1f nm\n',convB,LL1,2*pi/qn);

% convergence check (Nsh=2 vs 3)
S3=moire_setup(3,Nsc,theta,w,hbarv,cphi,K0);
e2c=sort(eig(buildH(S,0))); e3c=sort(eig(buildH(S3,0)));
fprintf('Central two-band manifold (2Nsc^2=%d near-zero states; single-band flat width along the mBZ path is 10.7 meV, see log_conv.txt): Nsh=%d: %.2f meV, Nsh=3: %.2f meV\n',...
    2*Nsc^2,Nsh,flatw(e2c,2*Nsc^2),flatw(e3c,2*Nsc^2));

% P matrix
nP=4*S.NPW; P=zeros(nP);  nMiss=0;
for l=0:1
  off=l*2*S.NPW;
  for i=1:S.NPW
    j=S.MAPg(-S.Ml(i)+S.Mo,-S.Nl(i)+S.No);
    if j>0
      P(off+2*(j-1)+1,off+2*(i-1)+1)=1;
      P(off+2*(j-1)+2,off+2*(i-1)+2)=1;
    else, nMiss=nMiss+1; end
  end
end
fprintf('P matrix: %d of %d (layer,sublattice) entries paired; %d unpaired (shell-edge truncation).\n',...
    nnz(P), nP, nP-nnz(P));

%% (a) normal-state LDOS vs B_s
dA=cell(numel(BsA),1);
for k=1:numel(BsA)
  dA{k}=ldos(EaxA,sort(eig(buildH(S,convB*BsA(k)))),etaN);
end

%% (d)+(b) BdG: QP gap vs B_s, two channels; store B_s=1 spectra
gI=zeros(size(BsD)); gV=gI; eBi=[]; eBv=[]; eB0=[];
for k=1:numel(BsD)
  a=convB*BsD(k); HK=buildH(S,a); Ht=buildH(S,-a);
  ei=sort(eig([HK,Delta0*P;Delta0*P',-conj(Ht)]));
  ev=sort(eig([HK,Delta0*P;Delta0*P',-conj(HK)]));
  gI(k)=min(ei(ei>0)); gV(k)=min(ev(ev>0));
  if BsD(k)==1, eBi=ei; eBv=ev; end
  if BsD(k)==0, eB0=ei; end
end
fprintf('\n(d) QP gap vs B_s (Δ0=%.1f meV):\n',Delta0);
fprintf('  B_s(T)   inter    intra    |diff| (meV)\n');
for k=1:numel(BsD)
  fprintf('  %5.2f  %7.3f  %7.3f  %9.2e\n',BsD(k),gI(k),gV(k),abs(gI(k)-gV(k)));
end

%% (c) valley spectral contrast vs B_real @ B_s = 1 T
%  Observable: C(B_real) = int |LDOS_K - LDOS_Kp| dE / int LDOS_K dE over a wide,
%  fixed window.  This is the correct measure for "the valley discrimination is
%  maximal at B_real = B_s": at B_real = B_s one valley's pseudo-field is cancelled
%  (B_s - B_real = 0) while the other one doubles (2 B_s).
%  NB the n=1 *peak-position* splitting used previously is NOT the right observable:
%  the pseudo-PLL at 33.6*sqrt(B) meV is not a dominant spectral feature at these
%  fields, so the old panel tracked a moire peak near 9 meV instead.
Ew=EaxA;
Cv=zeros(numel(BrC),1);
for k=1:numel(BrC)
  a=convB*BsC; ar=convB*BrC(k);
  eK =sort(eig(buildH(S, a+ar)));
  eKp=sort(eig(buildH(S,-a+ar)));
  dK=ldos(Ew,eK,etaN); dKp=ldos(Ew,eKp,etaN);
  dK=dK/max(dK); dKp=dKp/max(dKp);
  Cv(k)=trapz(Ew,abs(dK-dKp))/trapz(Ew,dK);
end
fprintf('\n(c) valley spectral contrast vs B_real @ B_s=1T:\n');
fprintf('  B_real(T)   C (contrast)\n');
for k=1:numel(BrC)
  fprintf('  %6.2f      %8.5f\n',BrC(k),Cv(k));
end
[~,imx]=max(Cv); fprintf('  -> C maximal at B_real = %.2f T (B_s = %.2f T)\n',BrC(imx),BsC);

%% ---------- figure: 按最终印刷尺寸布局 ----------
% 本图在主文以 0.68\textwidth = 0.68*510 pt = 4.82 in 的宽度印刷. 画布直接取该
% 尺寸: MATLAB 的 print 只按 PaperPosition 缩放几何, 字号/线宽是纸面上的绝对
% 点值, 画布必须 1:1 等于印刷尺寸, 8 pt 字号印出来才是 8 pt (Fig.1 约 8 pt).
FIN_W = 4.82;  FIN_H = FIN_W*850/1150;
S = 1;  FS = 8*S;  LWa = 0.75*S;  LWl = 1.2*S;

fig = figure('Color','w','Units','inches','Position',[1 1 S*FIN_W S*FIN_H]);
pos = [0.085 0.555 0.395 0.315;
       0.575 0.555 0.395 0.315;
       0.085 0.100 0.395 0.315;
       0.575 0.100 0.395 0.315];

% ---- (a) normal-state moiré LDOS vs B_s ----
ax_a = axes('Position',pos(1,:)); hold on;
cols=[0 0 0; 0 0.45 0.74; 0.85 0.33 0.1; 0.47 0.67 0.19];
for k=1:numel(BsA)
  plot(EaxA,dA{k}/max(dA{k}),'Color',cols(k,:),'LineWidth',LWl);
end
for n=1:3
  for k=2:numel(BsA)
    x=LL1*sqrt(n*BsA(k));
    if x<=180
      plot([x x],[0 0.10],':','Color',cols(k,:),'LineWidth',0.9*S,'HandleVisibility','off');
      plot([-x -x],[0 0.10],':','Color',cols(k,:),'LineWidth',0.9*S,'HandleVisibility','off');
    end
  end
end
xlabel('\itE\rm  (meV)'); ylabel('LDOS (norm.)');
title(['(a) normal-state moir' char(233) 'e LDOS']);
lg=legend(arrayfun(@(b) sprintf('\\itB\\rm_s = %g T',b),BsA,'UniformOutput',false), ...
          'Location','north','NumColumns',2);
set(lg,'FontSize',FS*0.85,'Box','on');
axis(ax_a,[-185 185 0 1.52]); grid on;

% ---- (b) BdG LDOS at B_s = 1 T ----
ax_b = axes('Position',pos(2,:)); hold on;
m=EaxB>-30 & EaxB<30;
d0=ldos(EaxB,eB0,etaB); di=ldos(EaxB,eBi,etaB); dv=ldos(EaxB,eBv,etaB);
n0=d0(m)/max(d0(m)); ni=di(m)/max(di(m)); nv=dv(m)/max(dv(m));
% 粗实线 intervalley 在下, 细虚线 intravalley 叠在上: "两条通道重合"本身即结论
h0=plot(EaxB(m),n0,'Color',[0.65 0.65 0.65],'LineWidth',1.0*S,'LineStyle',':', ...
        'HandleVisibility','off');
h_i=plot(EaxB(m),ni,'Color',[0.85 0.33 0.1],'LineWidth',2.6*S);
h_v=plot(EaxB(m),nv,'Color',[0.05 0.05 0.05],'LineWidth',1.1*S,'LineStyle','--');
xlabel('\itE\rm  (meV)'); ylabel('BdG LDOS (norm.)');
title('(b) BdG LDOS at \itB\rm_s = 1 T');
% 曲线最高只到 1.0, 故 ylim 抬到 1.42, 顶部 1.0~1.42 为空白带:
% 左放图例 + 说明文字, 右放内嵌图, 三者互不压线.
axis(ax_b,[-30 30 0 1.42]); grid on;
lg=legend([h_i h_v],{'singlet','triplet'},'Location','northwest');
set(lg,'FontSize',FS*0.85,'Box','on');
text(29.4,0.93,'max|\Delta| = 6.5\times10^{-5}','FontSize',FS*0.72, ...
     'HorizontalAlignment','right');

% 内嵌图 (b): |inter-intra| 的对数坐标, 放在顶部空白带右半, 悬于所有谱线之上
ax_in = axes('Position',[pos(2,1)+0.58*pos(2,3), pos(2,2)+0.735*pos(2,4), ...
                         0.31*pos(2,3), 0.185*pos(2,4)]);
diff_ldos = abs(ni - nv);
semilogy(EaxB(m), max(diff_ldos,1e-12), 'k-', 'LineWidth',0.9*S);
xlim([-30 30]); ylim([1e-6 1e-3]);
set(ax_in,'FontSize',FS*0.72,'XTick',[-30 0 30],'XTickLabel',[], ...
    'YTick',[1e-6 1e-4],'YAxisLocation','right','TickDir','out', ...
    'TickLength',[0.02 0.02],'Layer','top');
grid on; title('|inter-intra| (log)','FontSize',FS*0.72,'FontWeight','normal');

% ---- (c) valley spectral contrast vs B_real ----
ax_c = axes('Position',pos(3,:)); hold on;
[~,imxC]=max(Cv); ymx=max(Cv);
plot(BrC,Cv,'o-','LineWidth',LWl,'MarkerSize',5*S,'MarkerFaceColor','w');
plot([BsC BsC],[0 1.12*ymx],'k:','LineWidth',1.0*S,'HandleVisibility','off');
text(BsC+0.07,0.07*ymx,'\itB\rm_s','FontSize',FS*0.92);
plot(BrC(imxC),Cv(imxC),'o','MarkerSize',8*S,'MarkerFaceColor',[0.85 0.33 0.1], ...
     'MarkerEdgeColor','k','HandleVisibility','off');
xlabel('\itB\rm_{real}  (T)'); ylabel('valley contrast  \itC\rm');
title(sprintf('(c) valley contrast, max at %.2f\\itB\\rm_s',BrC(imxC)/BsC));
axis(ax_c,[0 max(BrC) 0 1.35*ymx]); grid on;

% ---- (d) quasiparticle gap vs B_s ----
ax_d = axes('Position',pos(4,:)); hold on;
h_gI=plot(BsD,gI,'o-','LineWidth',LWl,'MarkerSize',5*S,'MarkerFaceColor','w');
h_gV=plot(BsD,gV,'s-','LineWidth',LWl,'MarkerSize',5*S,'MarkerFaceColor','w');
plot([0 max(BsD)],[Delta0 Delta0],'k:','LineWidth',1.0*S,'HandleVisibility','off');
xlabel('\itB\rm_s  (T)'); ylabel('quasiparticle gap (meV)');
title('(d) quasiparticle gap');
lg=legend([h_gI h_gV],{'intervalley (\itK\rm,\itK\rm'')','intravalley (\itK\rm,\itK\rm)'}, ...
          'Location','east');
set(lg,'FontSize',FS*0.85,'Box','on');
axis(ax_d,[0 2 0.42 1.66]); grid on;

for a=[ax_a ax_b ax_c ax_d]
  set(a,'FontSize',FS,'TickDir','out','Box','on','LineWidth',LWa,'Layer','top');
end
save_paper_figs(fig, mfilename, [FIN_W FIN_H]);
fprintf('\nsaved %s (%.2f x %.2f in printing size, %g pt effective)\n', ...
        mfilename, FIN_W, FIN_H, FS/S);

%% ======================= 局部函数 =======================
function S = moire_setup(Nsh, Nsc, theta, w, hbarv, cphi, K0)
    psi = theta/2*pi/180;
    KT = K0*[cos(psi); sin(psi)]; KL = K0*[cos(psi); -sin(psi)];
    dK = KT-KL;
    R3 = [cos(2*pi/3) -sin(2*pi/3); sin(2*pi/3) cos(2*pi/3)];
    S.G1 = dK - R3*dK; S.G2 = dK - R3'*dK;
    S.RT = [cos(psi) -sin(psi); sin(psi) cos(psi)]; S.RL = S.RT';
    S.dK = dK; S.hbarv = hbarv; S.Nsc = Nsc;
    Rb = (Nsh+1)*Nsc - 1;
    [MT, TT] = ndgrid(-Rb:Rb, -Rb:Rb);
    S.Ml = MT(:);  S.Nl = TT(:);  S.NPW = numel(S.Ml);
    S.GX = (S.Ml*S.G1(1)+S.Nl*S.G2(1))/Nsc; S.GY = (S.Ml*S.G1(2)+S.Nl*S.G2(2))/Nsc;
    S.Mo = Rb+1; S.No = Rb+1;
    S.MAPg = zeros(2*S.Mo, 2*S.No);
    S.MAPg(sub2ind([2*S.Mo, 2*S.No], S.Ml+S.Mo, S.Nl+S.No)) = 1:S.NPW;
    qv = S.G1/Nsc; S.ah = [-qv(2) qv(1)]/norm(qv);
    S.Tj = cell(1,3); I2=eye(2); sx=[0 1; 1 0]; sy=[0 -1i; 1i 0];
    for j = 1:3
        phj = cphi + 2*pi*(j-1)/3;
        S.Tj{j} = w*(I2 + cos(phj)*sx + sin(phj)*sy);
    end
end

function H = buildH(S, amp)
    n = S.NPW; b2 = 2*n;
    sx = [0 1; 1 0]; sy = [0 -1i; 1i 0];
    sah = S.ah(1)*sx + S.ah(2)*sy;
    TT = zeros(b2); LL = zeros(b2); TL = zeros(b2); F = zeros(b2);
    for i = 1:n
        qT = S.RT*[S.GX(i); S.GY(i)];
        qL = S.RL*(S.dK + [S.GX(i); S.GY(i)]);
        TT(2*i-1:2*i,2*i-1:2*i) = S.hbarv*(sx*qT(1)+sy*qT(2));
        LL(2*i-1:2*i,2*i-1:2*i) = S.hbarv*(sx*qL(1)+sy*qL(2));
    end
    dmn = [0 0; S.Nsc 0; 0 S.Nsc];
    for i = 1:n
        for j = 1:3
            l = gidx(S, S.Ml(i)-dmn(j,1), S.Nl(i)-dmn(j,2));
            if l > 0
                TL(2*i-1:2*i, 2*l-1:2*l) = TL(2*i-1:2*i, 2*l-1:2*l) + S.Tj{j};
            end
        end
        lp = gidx(S, S.Ml(i)+1, S.Nl(i));  lm = gidx(S, S.Ml(i)-1, S.Nl(i));
        if lp > 0, F(2*lp-1:2*lp,2*i-1:2*i) = F(2*lp-1:2*lp,2*i-1:2*i) + (1i*amp/2)*sah; end
        if lm > 0, F(2*lm-1:2*lm,2*i-1:2*i) = F(2*lm-1:2*lm,2*i-1:2*i) - (1i*amp/2)*sah; end
    end
    H = [TT+F, TL; TL', LL+F];
    H = (H+H')/2;
end

function l = gidx(S, M, N)
    l = 0;
    if M > -S.Mo && M < S.Mo && N > -S.No && N < S.No
        l = S.MAPg(M+S.Mo, N+S.No);
    end
end

function wd = flatw(e, ns)
    [~,o] = sort(abs(e));
    wd = max(e(o(1:ns))) - min(e(o(1:ns)));
end

function d = ldos(E, ev, eta)
    d = zeros(size(E));
    for n = 1:numel(ev)
        d = d + (eta/pi)./((E-ev(n)).^2 + eta^2);
    end
end
