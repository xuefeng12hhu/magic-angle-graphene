function [Wc, vst] = bm_Wv(theta, w, Nsh, nk, cphi, sph, sdm, srt, K0, hbarv)
% 平带(带 2NG+1)带宽 Wc; v*: 在 98/99 带隙最小的 BZ 角(狄拉克点)单侧差分
    S = bm_geom(theta, w, Nsh, nk, cphi, sph, sdm, srt, K0, hbarv);
    for ik=1:numel(S.kx)
        S.E(ik,:) = bm_eval(S, [S.kx(ik) S.ky(ik)]);
    end
    Wc = max(S.E(:,S.b+1)) - min(S.E(:,S.b+1));
    d = 0.03*sqrt(sum(S.G1.^2));  u = S.G1/sqrt(sum(S.G1.^2));
    bestg = inf;  vst = nan;
    for ic=1:size(S.corners,2)
        kc = S.corners(:,ic)';
        e0 = bm_eval(S, kc);  gp = abs(e0(S.b+1)-e0(S.b));
        if gp < bestg
            bestg = gp;
            e1 = bm_eval(S, kc+u*d);
            vst = abs(e1(S.b+1)-e0(S.b+1))/d;
        end
    end
end
