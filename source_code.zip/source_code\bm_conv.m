%% bm_conv.m —— 检查左支 (θ<1.05°) 的 Nsh 收敛性
clear; clc;
a0 = 0.246; hbarv = 610; w = 110; K0 = 4*pi/(3*a0);
cphi = 7*pi/6; sph = 1; sdm = 1; srt = 1;

fprintf('=== 左支收敛性检查 (Nsh=2 vs 3) ===\n');
fprintf('  θ(°)   W(Nsh=2)  W(Nsh=3)   v*(Nsh=2)  v*(Nsh=3)\n');
for th = [0.70 0.80 0.90 1.00 1.05 1.10 1.20]
    [W2, v2] = bm_Wv(th, w, 2, 3, cphi, sph, sdm, srt, K0, hbarv);
    [W3, v3] = bm_Wv(th, w, 3, 3, cphi, sph, sdm, srt, K0, hbarv);
    fprintf('  %5.2f  %8.2f  %8.2f   %8.4f   %8.4f\n', th, W2, W3, v2/hbarv, v3/hbarv);
end
