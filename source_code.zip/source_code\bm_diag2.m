%% bm_diag2.m —— 检查左支 "平带" 是否仍为中央带对 (指数 2NG, 2NG+1)
clear; clc;
a0 = 0.246; hbarv = 610; w = 110; K0 = 4*pi/(3*a0);
cphi = 7*pi/6; sph = 1; sdm = 1; srt = 1; Nsh = 2;

for th = [0.70 0.90 1.05]
    S = bm_geom(th, w, Nsh, 3, cphi, sph, sdm, srt, K0, hbarv);
    NG = S.NG; b2 = 2*NG;
    fprintf('\n=== θ=%.2f°, NG=%d, 中央指数 b=%d ===\n', th, NG, b2);
    % Γ 点谱 (附近 6 个带)
    eG = bm_eval(S, [0 0]);
    fprintf('  Γ: 带 %d..%d = ', b2-2, b2+3);
    fprintf('%.1f ', eG(b2-2:b2+3)); fprintf('meV\n');
    % 角点谱
    kc = S.corners(:,1)';
    eC = bm_eval(S, kc);
    fprintf('  角: 带 %d..%d = ', b2-2, b2+3);
    fprintf('%.1f ', eC(b2-2:b2+3)); fprintf('meV\n');
    % 全 k 网格中央带范围
    E = zeros(numel(S.kx), 4*NG);
    for ik=1:numel(S.kx), E(ik,:) = bm_eval(S, [S.kx(ik) S.ky(ik)]); end
    W_center = max(E(:,b2+1)) - min(E(:,b2+1));
    W_below  = max(E(:,b2-1)) - min(E(:,b2-1));
    W_above  = max(E(:,b2+3)) - min(E(:,b2+3));
    fprintf('  W(带 b)=%.1f  W(带 b-2)=%.1f  W(带 b+2)=%.1f meV\n', ...
        W_center, W_below, W_above);
    fprintf('  |E| 最小 4 带 (全网格 min|E|): ');
    Eabs = sort(min(abs(E), [], 1));
    fprintf('%.1f ', Eabs(1:4)); fprintf('meV\n');
end
