function e = bm_eval(S, k)
% 排序本征谱 (升序, 1×4NG)
    NG = S.NG;  b2 = 2*NG;
    sx = [0 1; 1 0];  sy = [0 -1i; 1i 0];
    TT = zeros(b2); LL = zeros(b2); TL = zeros(b2);
    for i=1:NG
        qT = S.RT*(k+[S.GX(i); S.GY(i)]);
        qL = S.RL*(S.dK + k+[S.GX(i); S.GY(i)]);
        TT(2*i-1:2*i,2*i-1:2*i) = S.hbarv*(sx*qT(1)+sy*qT(2));
        LL(2*i-1:2*i,2*i-1:2*i) = S.hbarv*(sx*qL(1)+sy*qL(2));
    end
    dmn = S.dmn;
    for i=1:NG
        for j=1:3
            m2 = S.MM(i) - S.s2*dmn(j,1);  n2 = S.NN(i) - S.s2*dmn(j,2);
            if abs(m2)<=S.Nsh && abs(n2)<=S.Nsh && abs(m2+n2)<=S.Nsh
                l = S.MAP(m2+S.Nsh+1, n2+S.Nsh+1);
                if l>0
                    TL(2*i-1:2*i, 2*l-1:2*l) = TL(2*i-1:2*i,2*l-1:2*l) + S.Tj{j};
                end
            end
        end
    end
    H = [TT, TL; TL', LL];
    e = eig(H, 'vector')';
    e = sort(e, 2);
end
