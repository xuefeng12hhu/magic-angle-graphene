%% bm_fine.m —— 精细扫描 W vs θ (0.45°-1.3°) 确认第一/第二近平带区结构
clear; clc;
a0 = 0.246; hbarv = 610; w = 110; K0 = 4*pi/(3*a0);
cphi = 7*pi/6; sph = 1; sdm = 1; srt = 1; Nsh = 2;

thV = 0.45:0.05:1.30;
fprintf('=== 精细 W(θ) 扫描 (Nsh=2) ===\n');
fprintf('  θ(°)   α       W(meV)   v*/vF\n');
for th = thV
    [W, v] = bm_Wv(th, w, Nsh, 3, cphi, sph, sdm, srt, K0, hbarv);
    al = w/(hbarv*2*K0*sin(th/2*pi/180));
    fprintf('  %5.2f  %6.3f  %7.2f  %7.4f\n', th, al, W, v/hbarv);
end
