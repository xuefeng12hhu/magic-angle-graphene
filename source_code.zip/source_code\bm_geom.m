function S = bm_geom(theta, w, Nsh, nk, cphi, sph, sdm, srt, K0, hbarv)
    psi = theta/2*pi/180;
    KT = K0*[cos(psi); sin(psi)];  KL = K0*[cos(psi); -sin(psi)];
    dK = KT - KL;
    c3 = cos(2*pi/3); s3a = sin(2*pi/3);
    R3 = [c3 -s3a; s3a c3];
    q2 = R3*dK;  q3 = R3'*dK;
    S.G1 = dK - q2;  S.G2 = dK - q3;
    S.dK = dK;
    mn = -Nsh:Nsh;
    [MM,NN] = ndgrid(mn,mn);
    keep = abs(MM+NN)<=Nsh;
    S.MM=MM(keep); S.NN=NN(keep);  S.NG=numel(S.MM);
    S.MAP = zeros(2*Nsh+1);
    S.MAP(sub2ind([2*Nsh+1 2*Nsh+1], S.MM+Nsh+1, S.NN+Nsh+1)) = 1:S.NG;
    S.GX = S.MM*S.G1(1)+S.NN*S.G2(1);  S.GY = S.MM*S.G1(2)+S.NN*S.G2(2);
    Rp = [cos(srt*psi) -sin(srt*psi); sin(srt*psi) cos(srt*psi)];
    S.RT = Rp;  S.RL = Rp';
    S.Tj = cell(1,3);  I2 = eye(2);  sx = [0 1; 1 0];  sy = [0 -1i; 1i 0];
    for j=1:3
        phj = cphi + sph*2*pi*(j-1)/3;
        S.Tj{j} = w*(I2 + cos(phj)*sx + sin(phj)*sy);
    end
    if sdm > 0, S.dmn = [0 0; 1 0; 0 1];
    else,       S.dmn = [0 0; -1 0; 0 -1];
    end
    S.s2=1; S.w=w; S.hbarv=hbarv; S.Nsh=Nsh;
    S.b = 2*S.NG;
    [c1,c2] = ndgrid(((0:nk-1)+0.5)/nk);
    S.kx = c1(:)*S.G1(1)+c2(:)*S.G2(1);
    S.ky = c1(:)*S.G1(2)+c2(:)*S.G2(2);
    C = [S.G1+S.G2, -(S.G1+S.G2), 2*S.G1-S.G2, S.G1-2*S.G2, 2*S.G2-S.G1, S.G2-2*S.G1]/3;
    M = [S.G1, S.G2, S.G1+S.G2, S.G1-S.G2, -S.G1, -S.G2]/2;
    S.corners = C;
    S.kx = [S.kx; 0; C(1,:)'; M(1,:)'];
    S.ky = [S.ky; 0; C(2,:)'; M(2,:)'];
end
