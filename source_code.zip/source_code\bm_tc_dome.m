%% bm_tc_dome.m —— §6 升级: BM 生产扫描 + BCS 映射替代唯象 log-高斯穹顶
% 输入: 三锚验证的 BM 哈密顿量 (cphi=7π/6, sph=+1, sdm=+1, srt=+1)
% 步骤:
%   1) θ ∈ [0.7°, 1.8°] 23 点生产扫描: W(θ) 平带带宽 + v*(θ) 重整化速度
%   2) BCS 映射: T_c(θ) = T_c^max · exp[(W(θ)-W_min)/V_eff]
%      V_eff 由 (i) T_c(θ_m=1.05°)=1.7 K (Cao et al., Nature 556, 43 (2018))
%              (ii) 实验穹顶宽度 (T_c≈0.3 K @ 1.5°) 联合定标
%   3) 与原 log-高斯唯象穹顶 + Cao 数据点对照
% 输出: T_c(θ) 表 + 图 bm_tc_dome_fig1.png + 数据 bm_tc_dome.mat
% 依赖: bm_tbg_dome.m (bm_Wv 函数)
clear; clc; close all;

a0 = 0.246; hbarv = 610; w = 110; K0 = 4*pi/(3*a0);
Nsh = 2; nk = 3;
cphi = 7*pi/6; sph = 1; sdm = 1; srt = 1;
Tc_max = 1.7;
theta_m_anchor = 1.05;

% 扫描范围: 第一魔法角邻域 (W(θ) 在 [0.9°,1.05°] 与 [1.05°,1.8°] 各单调).
% θ≲0.85° 处 BM 模型出现"后续近平带区"(W 再次变平, 见 bm_fine.m/log_fine.txt),
% 与实验超导窗 (~0.9°-1.3°) 无关, 不纳入 T_c 映射.
thV = linspace(0.85, 1.80, 20);
WV = zeros(size(thV));  vV = zeros(size(thV));
fprintf('=== BM 生产扫描 (第一魔法角邻域, cphi=7π/6, sph=+1, sdm=+1, srt=+1) ===\n');
fprintf('   θ(°)    α       W_c(meV)   v*/v_F\n');
for i = 1:numel(thV)
    [WV(i), vV(i)] = bm_Wv(thV(i), w, Nsh, nk, cphi, sph, sdm, srt, K0, hbarv);
    alpha = w / (hbarv * 2*K0*sin(thV(i)/2*pi/180));
    fprintf('  %5.3f  %6.3f  %8.2f   %7.4f\n', thV(i), alpha, WV(i), vV(i)/hbarv);
end
[~, idx_min] = min(WV);
theta_m = thV(idx_min);
W_min = WV(idx_min);
fprintf('\n魔法角位置: θ_m = %.3f° (W_min = %.2f meV)\n', theta_m, W_min);

% BCS 映射: T_c(θ) = T_c^max · exp[-(W(θ)-W_min)/V_eff] (W 大则 N(0) 小, T_c 降)
i15 = find(abs(thV-1.5)<0.04, 1);
W_15 = WV(i15);
V_eff = (W_15 - W_min) / log(Tc_max/0.3);
fprintf('\nBCS 映射定标: V_eff = %.2f meV (基于 W(%.2f°)=%.1f meV 处 T_c≈0.3 K)\n', ...
    V_eff, thV(i15), W_15);
Tc_BCS = Tc_max * exp(-(WV - W_min)/V_eff);

% log-高斯唯象穹顶 (原 §6 实现)
wL = 0.40;
Tc_LG = Tc_max * exp(-(log(thV/theta_m_anchor)).^2 / (2*wL^2));

% 实验数据点 (Cao et al. 2018, 近似描点)
thExp = [0.90 0.95 1.00 1.05 1.10 1.15 1.20];
TcExp = [0.10 0.40 0.90 1.70 1.20 0.70 0.30];

figure('Color','w','Position',[50 50 900 600]);
subplot(1,2,1); hold on;
% 完整 W(θ) (含被排除的后续近平带区) 作灰色虚线背景
thFull = 0.45:0.05:1.80;  WFull = nan(size(thFull));
for i=1:numel(thFull)
    if min(abs(thV-thFull(i))) > 1e-6
        WFull(i) = bm_Wv(thFull(i), w, Nsh, nk, cphi, sph, sdm, srt, K0, hbarv);
    end
end
plot(thFull, WFull, '-', 'LineWidth', 1, 'Color',[0.7 0.7 0.7]);
plot(thV, WV, 'o-', 'LineWidth', 1.8, 'Color',[0 0.45 0.74], 'MarkerFaceColor','w');
yl = ylim; plot([0.85 0.85], yl, 'k--');
plot([theta_m theta_m], yl, 'k--');
xlabel('\theta (°)'); ylabel('W_c (meV)'); grid on; ylim(yl);
title('(a) BM flat-band width');
legend({'full W(\theta) (incl. higher near-flat bands)', 'first magic-angle window (used in mapping)', ...
        sprintf('valley edge 0.85° | \\theta_m=%.2f°', theta_m)}, 'Location', 'northwest');

subplot(1,2,2); hold on;
plot(thV, Tc_BCS, 'o-', 'LineWidth', 1.5, 'Color',[0.85 0.33 0.1], 'MarkerFaceColor','w');
plot(thV, Tc_LG, 's--', 'LineWidth', 1.5, 'Color',[0 0 0], 'MarkerSize',6);
plot(thExp, TcExp, 'rx', 'LineWidth', 1.5, 'MarkerSize', 10);
xlabel('\theta (°)'); ylabel('T_c (K)'); grid on;
title('(b) T_c dome: BM+BCS (first-principles) vs log-Gaussian (old) vs experiment');
legend({'BM+BCS (this work)', 'log-Gaussian (old §6)', 'Cao et al. 2018 experiment'}, 'Location','northeast');

save_paper_figs(gcf, 'bm_tc_dome');
fprintf('\n已保存 bm_tc_dome_fig1.png\n');

fprintf('\n=== T_c(θ) 表 ===\n');
fprintf('  θ(°)   W(meV)  T_c^BCS(K)  T_c^LG(K)\n');
for i = 1:numel(thV)
    fprintf('  %5.2f  %6.2f  %9.3f  %9.3f\n', thV(i), WV(i), Tc_BCS(i), Tc_LG(i));
end

save('bm_tc_dome.mat', 'thV', 'WV', 'vV', 'Tc_BCS', 'theta_m', 'W_min', 'V_eff');
fprintf('\n已保存 bm_tc_dome.mat (供 gl_phase_diagram.m 调用)\n');
