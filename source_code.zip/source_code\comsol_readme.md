# COMSOL 应变场回代接口 (§11)

把外部弹性求解器（COMSOL / 弹性-相场 / FEM）导出的应变张量场回代到本工作的
赝规范场 → GL/BdG 流水线。**无需修改任何主脚本**，只把导出文件放到
`matlab/` 目录并在 `gl_straingradient_vortex.m` 里设 `mode='file'`。

## 文件格式（两种，任选）

### 1. MATLAB `.mat`（推荐，快）

```matlab
save('strain_comsol.mat', 'xg', 'yg', 'eps_xx', 'eps_yy', 'eps_xy');
```

| 变量 | 含义 | 单位 | 形状 |
|---|---|---|---|
| `xg`, `yg` | 网格坐标（一维） | nm | `1×N`（两个方向点数可不同） |
| `eps_xx`, `eps_yy`, `eps_xy` | 面内应变张量（无量纲） | — | `N_x×N_y`（**ndgrid 排列**，见下） |

也接受预处理过的 `eps_p = eps_xx-eps_yy` / `eps_x = 2*eps_xy`（跳过减法）。

### 2. 文本 `.csv`（COMSOL "导出表格" 直出）

```text
% 任意注释行（% 开头）与表头行自动跳过
x_nm,y_nm,eps_xx,eps_yy,eps_xy
-960.0000,-960.0000,1.234567e-05,...
...
```

- 列名固定如上（前 5 列）；点**顺序任意**（由坐标重建网格，散射点自动 `@mean` 归并）。
- 坐标单位 nm，应变无量纲。

## 坐标系与数组约定

- 原点在**域中心**，X 沿晶格 `a1`，Y 沿 `a2`（与 GL 主仿真一致）。
- `.mat` 内部按 **ndgrid** 排列：`dim 1`（行）= X 方向，`dim 2`（列）= Y 方向。
  若从 `meshgrid` 流程导出，保存前转置一次即可：
  `eps_xx = eps_xx.'; % meshgrid -> ndgrid`
- `.csv` 无排列要求（坐标重建）。
- 导出网格分辨率建议 **≥ 2× 仿真网格**（当前仿真 512²@3.75 nm；示例脚本用 1024²），
  重采样用 `spline`（C²），交叉检验 L2 误差 1.7%。

## 回代公式（加载器自动完成）

```
eps_p = eps_xx - eps_yy ;  eps_x = 2*eps_xy        (去均值后)
a_x = C·eps_p,  a_y = -C·eps_x,  C = β/(2·a_CC)·ξ = 158.45 (β=3, a_CC=0.142 nm, ξ=15 nm)
B_s = Φ0/(π ξ²) · curl(a)/h                       (库珀对耦合 2a_s 在 relax_gl 内取 exp(-2i·a))
```

## 调用

```matlab
% gl_straingradient_vortex.m 参数区:
mode = 'file';  strain_file = 'strain_comsol.mat';
```

## 示例与验证（`verify_comsol_backsub.m`，全流程 < 10 min）

`make_demo_strain_mat.m` 生成四种典型几何（模拟 COMSOL 导出）：

| 几何 | 物理图像 | \|B_s\|max | B_s/B_c2 | 涡旋 |
|---|---|---|---|---|
| `uniax` | 高斯包络单轴梯度 + 泊松 + 剪切 | 602 mT | 0.411 | 74+/74− |
| `bubble` | 衬底气泡（双轴径向，无剪切） | 155 mT | 0.106 | 106+/106− |
| `wrinkle` | 一维正弦波纹（沿 X） | **0 mT** | 0 | 0 |
| `edge` | 边缘约束梯度（窗化，周期安全） | 25 mT | 0.017 | 53+/53− |

`wrinkle` 的 B_s ≡ 0 是**物理结果**：纯纵向应变梯度（∂_X ε ≠ 0，ε_xy = 0）不产生
赝磁场——赝场只对**横向**应变梯度响应（a_x 的旋度取 ∂_Y，a_y 的取 ∂_X）。

端到端自检（`verify_comsol_backsub.m`）：
1. **交叉检验**：`uniax` 文件加载（1024²→512² spline）vs 逐分量解析式 →
   B_s 场相对 L2 差 **1.7%**，涡旋数 80 vs 77；
2. 四几何 B_s + GL 涡旋响应（净通量全部 ≈ 0，验证周期边界无泄漏）；
3. CSV 任意顺序解析 vs 期望值，误差 < 1e-9（`%.6e` 格式截断底）。

## 常见坑（本工作调试实录）

1. **meshgrid vs ndgrid**：COMSOL 表格常按 meshgrid 行序输出，而 `curlz` 假定
   ndgrid。`.mat` 端请转置；`.csv` 端已由坐标重建免疫。
2. **剪切分量不可丢**：`uniax` 几何若解析式只写 ε_p 而丢 ε_x=2ε_xy，B_s 会
   差 ~1.9×（602 vs 322 mT，本次调试实测）。
3. **线性插值会削峰**：200² 导出 + linear 重采样使 |B_s|max 低 ~20%；
   用 spline 且 ≥2× 过采样后恢复到 1.7% 以内。
4. **表头行**：`x_nm,y_nm,...` 含逗号，`str2double` 得 NaN——解析器对含 NaN
   的行直接跳过。
