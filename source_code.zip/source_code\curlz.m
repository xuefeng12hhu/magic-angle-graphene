function bs = curlz(ax, ay)
% 中心差分 curl (z 分量); 周期边界
    bs = 0.5*(circshift(ay,-1,1)-circshift(ay,1,1)) - 0.5*(circshift(ax,-1,2)-circshift(ax,1,2));
end
