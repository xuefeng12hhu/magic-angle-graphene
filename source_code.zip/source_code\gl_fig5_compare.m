%% gl_fig5_compare.m —— Fig.5a 定稿: 三条 <psi^2> – B_s/B_c2 响应曲线
% 数据全部为本机实测 (见对应 diary 日志), 此处仅作图:
%  [1] 均匀赝场        : gl_pseudofield_vortex.m  (已归一化到零场)
%  [2] 振荡场 λ=8ξ     : log_runA.txt  (h=ξ/4, N=256)
%  [3] 振荡场 λ=32ξ    : log_lam32sweep.txt  (h=ξ/4, N=256, 迭代已验收敛)
clear; close all;

% --- [1] 均匀赝场 (归一化) ---
bu = [0 0.0031 0.0123 0.0491 0.0982 0.1964 0.3927 0.7854];
fu = [1 0.992 0.965 0.908 0.842 0.734 0.555 0.252];

% --- [2] 振荡场 λ=8ξ ---
b8 = [0 0.124 0.247 0.371 0.495 0.618 0.742 0.866 1.113 1.484];
f8 = [0.9978 0.9671 0.9398 0.9160 0.8910 0.8666 0.8481 0.8258 0.7905 0.7320];

% --- [3] 振荡场 λ=32ξ ---
b32= [0 0.124 0.249 0.373 0.498 0.622 0.746 0.871 1.120 1.493 1.990];
f32= [0.9978 0.9570 0.9243 0.8954 0.8698 0.8468 0.8252 0.8027 0.7627 0.7074 0.6376];

figure('Color','w','Position',[80 80 760 560]); hold on; box on;
plot(bu,  fu,  'ro-', 'LineWidth',1.8, 'MarkerFaceColor','r');
plot(b8,  f8,  'bs--','LineWidth',1.8, 'MarkerFaceColor','b');
plot(b32, f32, 'k^-','LineWidth',1.8, 'MarkerFaceColor','k');
xline(1, 'k:', 'LineWidth',1.2);
text(1.02, 0.97, 'B_s = B_{c2}', 'FontSize',10);
xlabel('B_{s,max} / B_{c2}'); ylabel('normalized \langle|\psi|^2\rangle');
legend({'uniform', '\lambda = 8\xi', '\lambda = 32\xi'}, ...
        'Location','northeast','FontSize',10);
title('Condensate suppression: uniform vs sign-changing pseudo-field');
ylim([0 1.02]); grid on;

save_paper_figs(gcf, 'gl_fig5_compare');
fprintf('=== 同一 B_s 下三条曲线对比 (实测范围内的插值) ===\n');
fprintf('  B_s/B_c2   uniform    lam=8xi    lam=32xi\n');
for b = [0.125 0.25 0.5 0.75 1.0]
    fprintf('  %6.2f   %7.3f   %7.3f    %7.3f\n', b, ...
        max(0, interp1(bu,fu,b,'linear')), ...
        interp1(b8,f8,b,'linear'), ...
        interp1(b32,f32,b,'linear'));
end
fprintf('lam=32xi 实测高场点: 1.120 -> 0.763,  1.493 -> 0.707,  1.990 -> 0.638 (仍不归零)\n');
fprintf('lam=8xi  实测高场点: 1.113 -> 0.791,  1.484 -> 0.732\n');
fprintf('已保存 gl_fig5_compare_fig1.png\n');
