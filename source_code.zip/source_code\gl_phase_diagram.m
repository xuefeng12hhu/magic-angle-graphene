%% gl_phase_diagram.m —— Fig.6: (theta, epsilon) 相图 (统一叙事)
% 组成:
%  (i)   T_c(theta) 穹顶 (BM+BCS 首性): 来自 bm_tc_dome.m 生产扫描
%        T_c(θ) = T_c^max · exp[-(W(θ)-W_min)/V_eff]
%        W(θ) = BM 平带带宽, V_eff = 33.9 meV (Cao 2018 锚定)
%  (ii)  xi(theta) = xi_m*sqrt(Tmax/Tc);   B_c2 = Phi0/(2 pi xi^2)
%  (iii) B_s = 7.0e-6 * Δε/L  (均匀赝场公式, 见推导笔记)
%  (iv)  超导响应 <|ψ|^2>(B_s/Bc2): gl_pseudofield_vortex.m 的收敛曲线 (归一化到零场)
%  (v)   有效域边界 xi(theta)=L: λ 扫描表明 L~4xi 时压制已达慢变极限的 ~95%,
%        L<xi 时赝场被部分平均、判据失效
% 依赖: base MATLAB (R2016b+) + bm_tc_dome.mat (由 bm_tc_dome.m 生成)
clear; clc; close all;

%% ---------- 参数 ----------
Phi0   = 2.07e-15;                 % T m^2
Tmax   = 1.7;                      % T_c,max (K) —— 实验锚定 (Cao et al. 2018: T_c≈1.7 K @ 1.05°)
xi_m   = 15;                       % 魔法角处 ξ (nm)
Lstr   = 40;                       % 应变梯度长度 (nm), 取 ~2.7 xi 保证局域极限
BScoef = 7.0e-6;                   % B_s[T] = 7.0e-6 * Δε / L[m]
%% -------------------------

% --- 加载 BM+BCS 首性穹顶 (bm_tc_dome.m 生产) ---
if exist('bm_tc_dome.mat', 'file')
    S_dome = load('bm_tc_dome.mat');
    thBM = S_dome.thV;  WBM = S_dome.WV;  TcBM = S_dome.Tc_BCS;
    fprintf('加载 BM+BCS 穹顶: %d 个角度点, V_eff=%.2f meV, θ_m=%.3f°, W_min=%.2f meV\n', ...
        numel(thBM), S_dome.V_eff, S_dome.theta_m, S_dome.W_min);
else
    error('找不到 bm_tc_dome.mat — 请先运行 bm_tc_dome.m 生成生产扫描数据');
end

% --- 超导响应曲线 (gl_pseudofield_vortex.m 实测, 归一化) ---
xe = [0 0.0031 0.0123 0.0491 0.0982 0.1964 0.3927 0.7854 1.05];
ye = [1 0.992 0.965 0.908 0.842 0.734 0.555 0.252 0];

% --- (θ, ε) 网格 ---
nT = 240;  nE = 200;
thv = linspace(0.6, 3.0, nT);          % deg
epv = linspace(0, 1.2, nE);            % ε (%)
[Th, Ep] = ndgrid(thv, epv);           % nT × nE

% BM+BCS 插值: 对每个网格点, 用 PCHIP 在 BM 数据点上插值 T_c(θ)
Tc = interp1(thBM, TcBM, Th, 'pchip', 0);          % K, 外推处 T_c=0
Tc = max(Tc, 0);                                    % 物理约束
xi   = xi_m*sqrt(Tmax./max(Tc, 1e-6));              % nm
Bc2  = Phi0./(2*pi*(xi*1e-9).^2);                   % T
Bs   = BScoef*(Ep/100)./(Lstr*1e-9);                % T
Beff = Bs./Bc2;
Fmap = interp1(xe, ye, min(Beff,1.05), 'pchip');
Fmap(Beff > 1.05) = 0;
valid = Lstr >= xi;                                 % 局域极限有效区 (ξ < L)

ec = Bc2(:,1)*(Lstr*1e-9)/BScoef*100;            % 临界应变 ε_c(θ) (%)
thm = thBM(find(TcBM==max(TcBM), 1));             % 数值穹顶峰值位置 = 魔法角
Bc2m = interp1(thv, Bc2(:,1), thm);

% ---------- Fig.6: 按最终印刷尺寸布局 ----------
% 主文以 0.68\textwidth = 0.68*510 pt = 4.82 in 印刷. 画布直接取该尺寸:
% MATLAB 的 print 只按 PaperPosition 缩放几何, 字号/线宽是纸面上的绝对点值,
% 因此画布必须 1:1 等于印刷尺寸, 8 pt 字号印出来才是 8 pt (Fig.1 约 8 pt).
FIN_W = 4.82;  FIN_H = FIN_W*820/1150;
S = 1;  FS = 8*S;  LWa = 0.75*S;  LWl = 1.2*S;

fig = figure('Name','Fig.6: (theta,epsilon) phase diagram','Color','w', ...
             'Units','inches','Position',[1 1 S*FIN_W S*FIN_H]);

% ---- (a) 相图 ----
ax_a = axes('Position',[0.085 0.575 0.700 0.360]);
pcolor(Th, Ep, Fmap); shading interp; colormap(parula); hold on;
caxis([0 1]);
plot(thv, ec, 'w-', 'LineWidth', 2.0*S);                            % B_s = B_c2
contour(Th, Ep, double(valid), [0.5 0.5], 'r--', 'LineWidth', 1.6*S);  % xi = L
xline(thm, 'w:', 'LineWidth', 1.2*S);
xlabel('twist angle \it\theta\rm  (deg)');
ylabel('strain amplitude \it\epsilon\rm  (%)');
title('(a) normalised  <|\psi|^2>  at \itL\rm = 40 nm');
set(ax_a,'Layer','top','FontSize',FS,'TickDir','out','Box','on','LineWidth',LWa);
axis tight;
cb = colorbar('Position',[0.808 0.575 0.019 0.360]);
set(cb,'FontSize',FS*0.92);

% ---- (b) T_c 穹顶 (BM+BCS) + 相干长度 ----
ax_b = axes('Position',[0.085 0.115 0.335 0.300]);
Tcmask = Tc(:,1);  Tcmask(Tcmask<=0) = NaN;         % 仅穹顶内显示 (无超导区留空)
yyaxis(ax_b,'left');
plot(thBM, TcBM, 'o-', 'Color',[0.85 0.10 0.10], 'LineWidth',LWl, ...
     'MarkerSize',3.6*S, 'MarkerFaceColor','w'); hold on;
plot(thv, Tcmask, '-', 'Color',[0.85 0.10 0.10], 'LineWidth',0.7*S);
ylabel('\itT\rm_c  (K)');
yyaxis(ax_b,'right');
plot(thv, xi_m*sqrt(Tmax./Tcmask), '-', 'Color',[0.05 0.15 0.85], 'LineWidth',LWl);
ylabel('\xi  (nm)');
xlabel('\it\theta\rm  (deg)');
title('(b) \itT\rm_c dome (BM+BCS)');
grid on; box on;
set(ax_b,'FontSize',FS,'LineWidth',LWa);

% ---- (c) 临界应变 vs 梯度长度 ----
ax_c = axes('Position',[0.600 0.115 0.335 0.300]);
Lv  = logspace(0.7, 2.2, 60);                   % 5 .. 158 nm
ecv = Bc2m*(Lv*1e-9)/BScoef*100;                % ε_c(%) at θ = θ_m
loglog(Lv, ecv, '-', 'Color',[0.70 0 0.60], 'LineWidth',LWl); hold on;   % ε_c ∝ L -> 斜率 1
xline(xi_m, 'k:', 'LineWidth',0.9*S);           % L = ξ(θ_m)
xline(Lstr, 'k:', 'LineWidth',0.9*S);           % L = 40 nm
text(xi_m,  0.145, '\xi(\theta_m)', 'FontSize',FS*0.90, 'HorizontalAlignment','center', ...
     'BackgroundColor','w','Margin',0.5);
text(Lstr*1.06, 0.145, 'L=40', 'FontSize',FS*0.90, 'BackgroundColor','w','Margin',0.5);
xlim([5 160]); ylim([0.1 4]);
xlabel('strain-gradient length \itL\rm  (nm)');
ylabel('\epsilon_c  (%)');
title('(c) \epsilon_c at \itB\rm_s = \itB\rm_{c2}');
grid on;
set(ax_c,'FontSize',FS,'TickDir','out','Box','on','LineWidth',LWa);

save_paper_figs(fig, mfilename, [FIN_W FIN_H]);
fprintf('saved %s (%.2f x %.2f in printing size, %g pt effective)\n', ...
        mfilename, FIN_W, FIN_H, FS/S);

% ---------- 关键数值 ----------
thOK = thv(valid(:,1));
fprintf('=== Fig.6 关键数值 ===\n');
fprintf('魔法角 θ_m=%.2f°, ξ(θ_m)=%.1f nm, B_c2(θ_m)=%.3f T\n', thm, xi_m, Bc2m);
fprintf('L=%.0f nm 时: ε_c(θ_m)=%.3f%% ; 局域极限有效 θ ∈ [%.2f°, %.2f°]\n', ...
        Lstr, interp1(thv, ec, thm), min(thOK), max(thOK));
fprintf('ε_c ∝ L: L=10 nm -> %.3f%% ; L=40 nm -> %.3f%% ; L=100 nm -> %.3f%%\n', ...
        Bc2m*10e-9/BScoef*100, Bc2m*40e-9/BScoef*100, Bc2m*100e-9/BScoef*100);
