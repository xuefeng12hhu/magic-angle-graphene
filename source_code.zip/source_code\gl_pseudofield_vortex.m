%% gl_pseudofield_vortex.m
% =========================================================================
%  2D Ginzburg-Landau + 均匀等效(赝)磁场  —— 最小可运行算例
%  虚时梯度流(imaginary-time gradient flow) 松弛, 方格子 + Peierls 相位(规范不变)
%
%  物理:  A_eff = 2*qv*a_s   ->   B_eff = 2*qv*B_s
%         qv = 0 : 谷单态(intervalley)   -> B_eff = 0  -> 无涡旋 (|psi| 均匀)
%         qv = 1 : 谷三重态/谷极化       -> B_eff ~=0 -> 自发涡旋晶格
%
%  单位:  长度以相干长度 xi 为单位(h = 1); 磁通量子归一化为 2*pi
%  文献:  对应笔记 §6 / §8; 产出 Fig.2(|psi|,arg) 和 Fig.5(Tc 压制)
%
%  运行:  >> gl_pseudofield_vortex
%  依赖:  仅 base MATLAB, 不需要任何 toolbox
% =========================================================================
clear; clc; close all;
rng(1);

%% ------------------ 用户可调参数 ------------------
N     = 128;      % 网格 N x N, 格距 h = 1 (即 xi)
Nv    = 16;       % 全区域内的磁通量子数 (=体态涡旋数); 16=4x4 好看
qv    = 1;        % 库珀对谷荷: 0=谷单态, 1=谷三重态
dt    = 0.1;      % 梯度流时间步 (显式格式稳定要求 dt < 0.25)
nStp  = 8000;     % 迭代步数
xi_nm = 15;       % 相干长度(nm), 仅用于物理单位换算
%% --------------------------------------------------

B_eff = qv * (2*pi*Nv/N^2);   % 每个 plaquette 的相量; qv=0 时自动归零

% ---------- Fig A: 单态 vs 三重态的 |psi| 与相位 ----------
psi_s = relax_gl(N, 0,     dt, nStp);
[psi_t, ene_t, nv_t] = relax_gl(N, B_eff, dt, nStp);

figure('Name','GL + 赝磁场: 序参量','Color','w','Position',[80 80 1000 470]);
subplot(2,2,1); imagesc(abs(psi_s)); axis image off; colorbar;
title('|\psi|,  B_{eff}=0  (q_v=0, valley singlet): uniform, no vortices');
subplot(2,2,2); imagesc(angle(psi_s)); axis image off; colorbar;
title('arg \psi'); ylabel(''); 
subplot(2,2,3); imagesc(abs(psi_t)); axis image off; colorbar;
title(sprintf('|\\psi|,  B_{eff}=%.4f  (q_v=1, valley triplet),  N_v=%d', B_eff, nv_t));
subplot(2,2,4); imagesc(angle(psi_t)); axis image off; colorbar;
title(sprintf('arg \\psi  (vortex lattice),  F=%.4f', ene_t));

% ---------- Fig B: 效场增强 -> 超导被压制 (对应临界梯度预言 P2) ----------
NvList  = [0 2 8 32 128 256 512 1024 2048];
avgList = zeros(size(NvList));
fprintf('参考: B_c2 (库珀对) <-> B_eff = 1 <-> Nv = N^2/(2*pi) = %.0f\n', N^2/(2*pi));
fprintf('扫描 B_eff (qv=1):\n');
for k = 1:numel(NvList)
    Bk = 2*pi*NvList(k)/N^2;
    pk = relax_gl(N, Bk, dt, 4000);
    avgList(k) = mean(abs(pk(:)).^2);
    fprintf('  Nv=%2d   B_eff=%.5f   <|psi|^2>=%.4f\n', NvList(k), Bk, avgList(k));
end
figure('Name','Pseudo-field suppresses superconductivity','Color','w');
plot(2*pi*NvList/N^2, avgList, 'o-','LineWidth',1.6,'MarkerFaceColor','r');
xlabel('B_{eff}  (dimensionless, phase per plaquette)');
ylabel('<\psi^2>');
title('Valley-triplet channel: pseudo-field quenches the condensate');
grid on;

% ---------- 物理单位换算 ----------
fprintf('\n物理单位换算 (xi = %g nm):\n', xi_nm);
physical_units(B_eff, xi_nm);
fprintf('说明: 若无量纲临界值 ~1, 则对应的物理临界梯度即 P2 的预言量级。\n');

% ---- 自动保存本脚本产生的图 (统一出版风格, 300 dpi) ----
figs = findall(0,'Type','figure');  [~,o] = sort([figs.Number]);  figs = figs(o);
save_paper_figs(figs, mfilename);

% ======================= 局部函数 =======================
function [psi, ene, nvort] = relax_gl(N, B, dt, nStp)
% 无量纲 GL 泛函的梯度流:
%   F = sum_bonds |psi_j - U_ij psi_i|^2 + sum( -|psi|^2 + 0.5|psi|^4 )
%   Landau 规范 A=(0, B*x):  Ux=1,  Uy=exp(-i B x_i)
    x  = (0:N-1)';                       % x(i), 格距 1
    Uy = exp(-1i*B*x);                   % N x 1, +y 跳跃相位
    Uc = conj(Uy);

    psi = 0.05*(randn(N,N) + 1i*randn(N,N));   % 小随机初值
    for it = 1:nStp
        % 离散协变 Laplacian (周期边界), Ux = 1
        lap = psi([2:N 1],:) + psi([N 1:N-1],:) ...
            + Uc.*psi(:,[2:N 1]) + Uy.*psi(:,[N 1:N-1]) - 4*psi;
        dpsi = lap + (1 - abs(psi).^2).*psi;      % = -dF/dpsi*
        psi  = psi + dt*dpsi;
    end
    ene   = energy(psi, Uy);
    nvort = count_vortices(psi, B);
end

function F = energy(psi, Uy)
    N  = size(psi,1);
    kx = abs(psi([2:N 1],:) - psi).^2;            % +x 键
    ky = abs(psi(:,[2:N 1]) - Uy.*psi).^2;        % +y 键
    F  = sum(kx(:)) + sum(ky(:)) ...
       + sum(-abs(psi(:)).^2 + 0.5*abs(psi(:)).^4);
end

function nv = count_vortices(psi, B)
% 规范不变的 plaquette 绕数:  N_v = round( (环绕 psi 的相位 - 磁通) / 2pi )
    N  = size(psi,1);
    p1 = psi;                      % (i  , j)
    p2 = psi([2:N 1],:);           % (i+1, j)
    p3 = psi([2:N 1],[2:N 1]);     % (i+1, j+1)
    p4 = psi(:,[2:N 1]);           % (i  , j+1)
    loop = angle(p2.*conj(p1)) + angle(p3.*conj(p2)) ...
         + angle(p4.*conj(p3)) + angle(p1.*conj(p4));
    nv = sum( round((loop(:) - B)/(2*pi)) ~= 0 );
end

function physical_units(B_eff, xi_nm)
    Phi0 = 2.07e-15;               % T m^2  (h/2e)
    xi   = xi_nm*1e-9;
    Bs   = B_eff*Phi0/(2*pi*xi^2); % 由无量纲 B_eff 得物理赝磁场
    grad = Bs/7.0e-6;              % 应变梯度 |d eps|/L  [1/m]
    fprintf('  B_eff=%.4f  ->  B_s=%.3f T  ->  应变梯度 %.2e /m (约 %.2f%% / 10 nm)\n', ...
            B_eff, Bs, grad, grad*10e-9*100);
end
