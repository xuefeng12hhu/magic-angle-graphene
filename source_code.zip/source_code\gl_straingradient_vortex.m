%% gl_straingradient_vortex.m
% 解析应变场 -> 单粒子赝规范场 a_s -> 赝磁场 b_s -> 非均匀 Peierls 相位下 GL 梯度流
% 约定: 库珀对耦合 2*qv*a_s (qv=1) -> GL 环节子取 exp(-2i a_s);  B_s = Phi0/(pi xi^2)*curl(a_s)
% 模式: 'grad' | 'bubble' | 'wave'(周期正弦) | 'file'(读 .mat)
% 单位: 长度以 xi=1; 格距 h=1; 磁通量子归一化 2*pi.  依赖: base MATLAB (R2016b+)
clear; clc; close all; rng(1);

%% ---------- 用户参数 ----------
N_base = 128;  xi_nm = 15;  mode = 'grad';
hfac   = 0.25;                          % 格距 h = hfac*xi (文献级: h <= xi/4)
eps0 = 6e-3;  sigma_nm = 150;  lambda_nm = 120;
strain_file = 'strain_comsol.mat';
dt = 0.1;  nStp = 15000;  avort = true;
N = round(N_base/hfac);  h_nm = xi_nm*hfac;
%% -----------------------------

beta = 3; a_cc = 0.142;                 % 赝场耦合 / C-C 键长(nm)
sigma = sigma_nm/h_nm;  lam = lambda_nm/h_nm;   % 换算为格点数
C = beta/(2*a_cc)*xi_nm;                % a_s(dimless) = C * strain

idx = 0:N-1; [Xg,Yg] = ndgrid(idx,idx); Xg = Xg-N/2; Yg = Yg-N/2;
G = @(x,y) exp(-(x.^2+y.^2)/(2*sigma^2));

% ---------- 应变场 ----------
switch lower(mode)
  case 'grad'
    eps_p = eps0*(Yg./sigma).*G(Xg,Yg);  eps_x = zeros(N);
  case 'bubble'
    r = sqrt(Xg.^2+Yg.^2); r2 = max(r.^2,1e-12);
    gg = -eps0*(r.^2./sigma^2).*exp(-r.^2/(2*sigma^2));
    eps_p = gg.*(Xg.^2-Yg.^2)./r2;  eps_x = gg.*(2*Xg.*Yg)./r2;
  case 'wave'
    eps_p = eps0*sin(2*pi*Yg/lam);  eps_x = zeros(N);
  case 'file'
    [eps_p, eps_x] = load_strain_field(strain_file, N, xi_nm);
  otherwise
    error('mode 必须是 grad|bubble|wave|file');
end

% ---------- 赝规范场 / 赝磁场 ----------
if avort
    ax =  C*eps_p;      % a_x = (beta/2a)(eps_xx-eps_yy)  [单粒子]
    ay = -C*eps_x;      % a_y = -(beta/2a)(2 eps_xy)
else
    ax = zeros(N); ay = zeros(N);
end
bs = curlz(ax,ay)/hfac;                        % 无量纲 b_s (单位 1/xi)

Phi0 = 2.07e-15;  Bc2 = Phi0/(2*pi*(xi_nm*1e-9)^2);
Bs_T = bs * Phi0/(pi*(xi_nm*1e-9)^2);          % <-- 修正: pi, 非 2*pi
rm = round(0.04*N);                            % 边缘留 4%, 避开周期环绕伪影
Bsmax = max(max(abs(Bs_T(rm+1:end-rm, rm+1:end-rm))));
fprintf('模式=%s | h=xi/%.1f, N=%d, 域=%.0f nm\n', mode, 1/hfac, N, N*h_nm);
fprintf('模式=%s | |B_s|max=%.2f mT | B_c2=%.0f mT | B_s/B_c2=%.3f | 净通量=%+.2f\n', ...
        mode, Bsmax*1e3, Bc2*1e3, Bsmax/Bc2, sum(bs(:))/(2*pi));

% ---------- GL 松弛 (库珀对耦合 2 qv a_s) ----------
[psi, ene, wmap] = relax_gl(N, exp(-2i*ax), exp(-2i*ay), dt, nStp);
fprintf('F=%.3f  涡旋计数 N_v=%d (正 %d / 负 %d)\n', ene, sum(wmap(:)~=0), ...
        sum(wmap(:)>0), sum(wmap(:)<0));

% ---------- 出图 ----------
figure('Name',['strain->a_s->b_s (' mode ')'],'Color','w','Position',[60 60 900 720]);
subplot(2,2,1); imagesc(ax); axis image off; colorbar; title('a_x');
subplot(2,2,2); imagesc(ay); axis image off; colorbar; title('a_y');
subplot(2,2,3); imagesc(bs); axis image off; colorbar; title('b_s=curl a_s');
subplot(2,2,4); imagesc(Bs_T*1e3); axis image off; colorbar; title('B_s [mT]');

% 谷单态对照 (无赝场, 应为均匀解)
psi0 = relax_gl(N, ones(N), ones(N), dt, nStp, ones(N));
figure('Name','GL: triplet vs singlet','Color','w','Position',[100 100 980 900]);
subplot(2,2,1); imagesc(abs(psi)); axis image; colorbar; hold on;
[ii,jj] = find(wmap~=0);
plot(jj(wmap(wmap~=0)>0), ii(wmap(wmap~=0)>0),'wo','MarkerSize',6,'LineWidth',1.2);
plot(jj(wmap(wmap~=0)<0), ii(wmap(wmap~=0)<0),'kx','MarkerSize',6,'LineWidth',1.2);
hold off; title(sprintf('Triplet |\\psi| (vortex=%d, antivortex=%d)',sum(wmap(:)>0),sum(wmap(:)<0)));
subplot(2,2,2); imagesc(angle(psi)); axis image off; colorbar; colormap(gca,hsv); title('Triplet: arg \psi');
subplot(2,2,3); imagesc(abs(psi0)); axis image; colorbar; title('Singlet |\psi| (no pseudo-field): uniform');
subplot(2,2,4); imagesc(angle(psi0)); axis image off; colorbar; colormap(gca,hsv); title('Singlet: arg \psi');

figs = findall(0,'Type','figure');  [~,o] = sort([figs.Number]);  figs = figs(o);
save_paper_figs(figs, mfilename);
fprintf('saved %d figures\n', numel(figs));

% ======================= 辅助函数已抽为独立文件 =======================
%   curlz.m, vortex_map.m, relax_gl.m, load_strain_field.m
% 本文件保留为单脚本, 调上述独立函数.  历史本地副本已删除.
