%% gl_sweep_gradient.m
% 批量扫描: 固定应变图案, 扫幅度 eps0 -> P2 定量图 (Fig.5)
% 默认 'wave' 周期正弦应变: b_s 正负交替且全覆盖 -> 平均序参量可靠.
% 谷三重态耦合赝场(2 qv a_s); 谷单态无耦合 (对照, 只算一次).
% 依赖: base MATLAB (R2016b+)
clear; clc; close all; rng(1);

%% ---------- 用户参数 ----------
N_base = 64;            % 域尺寸 = N_base * xi_nm (nm)
hfac   = 0.25;          % 格距 h = hfac * xi_nm (文献级: h <= xi/4)
xi_nm  = 15; mode = 'wave';
lambda_nm = 480; sigma_nm = 120;   % λ=32ξ: 缓变(饱和)区, SI §4.1 缺口数据
eps0List = [0 2 4 6 8 10 12 14 18 24 32]*1e-3;  % 4×旧列表: 保持同一 B_s 范围 (B_s∝ε/λ)
dt = 0.1; nStp = 15000;
doGridCheck  = false;   % true: 对 eps0List(end) 做 hfac 收敛性检查
doLambdaScan = false;   % true: 扫描应变梯度长度尺度 λ/xi (固定 B_s 与域)
doNstpCheck  = false;   % true: 对 λ=32ξ 做迭代步数收敛性检查
N = round(N_base/hfac);
h_nm = xi_nm*hfac;                      % 物理格距 (nm)
%% -----------------------------

Phi0 = 2.07e-15;  Bc2 = Phi0/(2*pi*(xi_nm*1e-9)^2);
area = (N*h_nm*1e-9)^2;                 % 物理面积 (m^2)
nE = numel(eps0List);
Bsmax=zeros(1,nE); ratio=zeros(1,nE); epsPct=zeros(1,nE);
psi2_t=zeros(1,nE); nvd_t=zeros(1,nE);

% 谷单态对照 (无赝场, 只算一次)
p0 = relax_gl(N, ones(N), ones(N), dt, nStp);  psi2_ref = mean(abs(p0(:)).^2);

fprintf('=== 应变扫描 mode=%s (lambda=%.0f nm, xi=%.0f nm, h=xi/%.1f, N=%d, 域=%.0f nm) ===\n', ...
        mode, lambda_nm, xi_nm, 1/hfac, N, N*h_nm);
fprintf(' eps0(%%)  B_s,max(mT)  B_s/B_c2  <|psi|^2>     N_v   t(s)\n');
for k = 1:nE
    tk = tic;
    eps0 = eps0List(k);
    ax = make_ax(N, h_nm, xi_nm, sigma_nm, lambda_nm, eps0, mode);  ay = zeros(N);
    bsk = curlz(ax,ay)/hfac;          % 无量纲 b_s (单位 1/xi)
    Bsmax(k) = max(abs(bsk(:)))*Phi0/(pi*(xi_nm*1e-9)^2);
    ratio(k) = Bsmax(k)/Bc2;  epsPct(k) = eps0*100;
    p  = relax_gl(N, exp(-2i*ax), exp(-2i*ay), dt, nStp);
    wm = vortex_map(p, exp(-2i*ax), exp(-2i*ay));
    psi2_t(k) = mean(abs(p(:)).^2);  nvd_t(k) = sum(wm(:)~=0)/area;
    fprintf(' %5.2f   %8.2f   %7.3f   %.4f   %6d   %5.1f\n', ...
            epsPct(k), Bsmax(k)*1e3, ratio(k), psi2_t(k), round(nvd_t(k)*area), toc(tk));
end

% ---------- Fig.5 ----------
figure('Name','P2: 赝场压制超导 (Fig.5)','Color','w','Position',[80 60 1080 760]);
subplot(2,2,1);
plot(ratio, psi2_t,'o-','LineWidth',1.7,'MarkerFaceColor','r'); hold on;
plot(ratio, psi2_ref*ones(size(ratio)),'k--','LineWidth',1.5);
xlabel('B_{s,max}/B_{c2}'); ylabel('<\psi^2>'); grid on;
title('(a) order parameter vs normalized pseudo-field'); legend('triplet','singlet','Location','southwest');
subplot(2,2,2);
semilogy(ratio, nvd_t+eps,'s-','LineWidth',1.7,'MarkerFaceColor','b');
xlabel('B_{s,max}/B_{c2}'); ylabel('n_v (m^{-2})'); grid on;
title('(b) vortex density vs normalized pseudo-field');
subplot(2,2,3);
plot(epsPct, psi2_t,'o-','LineWidth',1.7,'MarkerFaceColor','r'); hold on;
plot(epsPct, psi2_ref*ones(size(epsPct)),'k--','LineWidth',1.5);
xlabel('\epsilon_0 (%)'); ylabel('<\psi^2>'); grid on; title('(c) order parameter vs strain amplitude');
subplot(2,2,4);
plot(epsPct, Bsmax*1e3,'^-','LineWidth',1.7,'MarkerFaceColor','m'); hold on;
yline(Bc2*1e3,'k:','LineWidth',1.4);
xlabel('\epsilon_0 (%)'); ylabel('B_{s,max} (mT)'); grid on; title('(d) calibration: B_s \propto \epsilon_0');

figs = findall(0,'Type','figure');  [~,o] = sort([figs.Number]);  figs = figs(o);
save_paper_figs(figs, mfilename);
fprintf('已保存 %d 张图\n', numel(figs));

%% ---------- (可选) 格距收敛性检查 ----------
if doGridCheck
    fprintf('\n[格距收敛性] eps0 = %.2f%%\n', eps0List(end)*100);
    fprintf('   hfac       N   B_s,max(mT)  <|psi|^2>     N_v   t(s)\n');
    for hf = [hfac 1/6 1/8]
        tg = tic;
        Nc = round(N_base/hf);  hc = xi_nm*hf;
        axc = make_ax(Nc, hc, xi_nm, sigma_nm, lambda_nm, eps0List(end), mode);
        bck = curlz(axc, zeros(Nc))/hf;
        Bc  = max(abs(bck(:)))*Phi0/(pi*(xi_nm*1e-9)^2);
        pc  = relax_gl(Nc, exp(-2i*axc), ones(Nc), dt, nStp);
        wc  = vortex_map(pc, exp(-2i*axc), ones(Nc));
        fprintf('  1/%4.1f  %5d   %8.2f     %.4f   %6d   %5.1f\n', ...
                1/hf, Nc, Bc*1e3, mean(abs(pc(:)).^2), sum(wc(:)~=0), toc(tg));
    end
end

%% ---------- (可选) 应变梯度长度尺度 λ 扫描 ----------
% 固定域与 B_s,max, 只变 λ/xi: 检验'赝场只有相对 xi 缓变时才有效'
if doLambdaScan
    fprintf('\n[λ 扫描] 固定域 %.0f nm, 目标 B_s/B_c2 ≈ 1.1 (ε0 ∝ λ 以保持 B_s)\n', N*h_nm);
    fprintf('  λ/xi    λ(nm)  eps0(%%)  B_s,max(mT)  B_s/B_c2  <|psi|^2>     N_v   t(s)\n');
    for lamx = [4 8 16 32]
        tl = tic;
        e0  = 4.5e-3*(lamx/8);           % B_s ∝ eps0/λ -> 保持 B_s 不变
        axl = make_ax(N, h_nm, xi_nm, sigma_nm, lamx*xi_nm, e0, mode);
        bl  = curlz(axl, zeros(N))/hfac;
        Bl  = max(abs(bl(:)))*Phi0/(pi*(xi_nm*1e-9)^2);
        pl  = relax_gl(N, exp(-2i*axl), ones(N), dt, nStp);
        wl  = vortex_map(pl, exp(-2i*axl), ones(N));
        fprintf('  %4d   %6.0f   %5.2f    %8.2f    %6.3f    %.4f   %6d   %5.1f\n', ...
                lamx, lamx*xi_nm, e0*100, Bl*1e3, Bl/Bc2, mean(abs(pl(:)).^2), ...
                sum(wl(:)~=0), toc(tl));
    end
end

%% ---------- (可选) 迭代步数收敛性 ----------
if doNstpCheck
    lamn = 32*xi_nm;  e0 = 4.5e-3*4;
    axn = make_ax(N, h_nm, xi_nm, sigma_nm, lamn, e0, mode);
    bn  = curlz(axn, zeros(N))/hfac;
    fprintf('\n[nStp 收敛性] λ=%.0f nm, B_s/B_c2=%.3f\n', lamn, ...
            max(abs(bn(:)))*Phi0/(pi*(xi_nm*1e-9)^2)/Bc2);
    fprintf('    nStp   <|psi|^2>     N_v   t(s)\n');
    for ns = [15000 30000 60000]
        tn = tic;
        pn = relax_gl(N, exp(-2i*axn), ones(N), dt, ns);
        wn = vortex_map(pn, exp(-2i*axn), ones(N));
        fprintf('  %6d    %.4f   %6d   %5.1f\n', ns, mean(abs(pn(:)).^2), ...
                sum(wn(:)~=0), toc(tn));
    end
end

% ======================= 局部函数 =======================
function ax = make_ax(N, h_nm, xi_nm, sigma_nm, lambda_nm, eps0, mode)
    beta = 3; a_cc = 0.142; C = beta/(2*a_cc)*xi_nm;
    sigma = sigma_nm/h_nm; lam = lambda_nm/h_nm;   % 换算为格点数
    idx = 0:N-1; [Xg,Yg] = ndgrid(idx,idx); Xg = Xg-N/2; Yg = Yg-N/2;
    switch lower(mode)
      case 'wave'
        eps_p = eps0*sin(2*pi*Yg/lam);
      case 'grad'
        eps_p = eps0*(Yg./sigma).*exp(-(Xg.^2+Yg.^2)/(2*sigma^2));
      case 'bubble'
        r = sqrt(Xg.^2+Yg.^2); r2 = max(r.^2,1e-12);
        gg = -eps0*(r.^2./sigma^2).*exp(-r.^2/(2*sigma^2));
        eps_p = gg.*(Xg.^2-Yg.^2)./r2;
    end
    ax = C*eps_p;
end

function bs = curlz(ax, ay)
    bs = 0.5*(circshift(ay,-1,1)-circshift(ay,1,1)) - 0.5*(circshift(ax,-1,2)-circshift(ax,1,2));
end

function [psi, ene, wmap] = relax_gl(N, Ux, Uy, dt, nStp)
    psi = 0.05*(randn(N,N)+1i*randn(N,N));
    for it = 1:nStp
        lap = conj(Ux).*psi([2:N 1],:) + Ux([N 1:N-1],:).*psi([N 1:N-1],:) ...
            + conj(Uy).*psi(:,[2:N 1]) + Uy(:,[N 1:N-1]).*psi(:,[N 1:N-1]) - 4*psi;
        psi = psi + dt*(lap + (1-abs(psi).^2).*psi);
    end
    kx = abs(psi([2:N 1],:) - Ux.*psi).^2;
    ky = abs(psi(:,[2:N 1]) - Uy.*psi).^2;
    ene = sum(kx(:)) + sum(ky(:)) + sum(-abs(psi(:)).^2 + 0.5*abs(psi(:)).^4);
    wmap = vortex_map(psi, Ux, Uy);
end

function w = vortex_map(psi, Ux, Uy)
    N = size(psi,1);
    p1=psi; p2=psi([2:N 1],:); p3=psi([2:N 1],[2:N 1]); p4=psi(:,[2:N 1]);
    loop = angle(p2.*conj(p1)) + angle(p3.*conj(p2)) + angle(p4.*conj(p3)) + angle(p1.*conj(p4));
    ph = angle(Ux) + angle(Uy([2:N 1],:)) - angle(Ux(:,[2:N 1])) - angle(Uy);
    w = round((loop + ph)/(2*pi));
end
