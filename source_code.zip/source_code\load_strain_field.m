function [eps_p, eps_x] = load_strain_field(fname, N, xi_nm)
% 支持两种来源: .mat (结构体) 或 .csv (COMSOL 风格文本)
%   .mat: 字段 eps_xx/eps_yy/eps_xy (nm 坐标 xg/yg) 或 eps_p/eps_x
%   .csv: 列 x_nm,y_nm,eps_xx,eps_yy,eps_xy (前导 % 注释行可自动跳过)
% 输出: eps_p = eps_xx-eps_yy;  eps_x = 2*eps_xy   (与主脚本 a_x = C*eps_p, a_y = -C*eps_x 配对)
%
% 数组约定: 与主脚本 curlz 兼容 (Y 沿 dim 2 列, X 沿 dim 1 行), 即 ndgrid 排列.
%           导出端 make_demo_strain_mat 也用 ndgrid 存盘, 无需运行期转置.
    [~,~,ext] = fileparts(fname);
    if strcmpi(ext,'.csv')
        % CSV 格式: 列 x_nm,y_nm,eps_xx,eps_yy,eps_xy; % 注释行与表头行自动跳过;
        % 点顺序任意 (由坐标重建网格, 对 COMSOL 任意导出顺序稳健)
        fid = fopen(fname,'r');
        rownum = [];
        while true
            ln = fgetl(fid);
            if ~ischar(ln), break; end
            t = strtrim(ln);
            if isempty(t) || t(1)=='%', continue; end
            vals = str2double(strsplit(t,','));
            if numel(vals) >= 5 && ~any(isnan(vals(1:5)))
                rownum = [rownum; vals(1:5)];  %#ok
            end
        end
        fclose(fid);
        xcol = rownum(:,1); ycol = rownum(:,2);
        exx = rownum(:,3); eyy = rownum(:,4); exy = rownum(:,5);
        [ux,~,ix] = unique(xcol);  [uy,~,iy] = unique(ycol);
        ep = accumarray([iy ix], exx, [numel(uy) numel(ux)], @mean, 0);  % (Y行, X列)
        ey = accumarray([iy ix], eyy, [numel(uy) numel(ux)], @mean, 0);
        xy = accumarray([iy ix], exy, [numel(uy) numel(ux)], @mean, 0);
        ep = (ep - ey).';   ex = 2*xy.';   % -> ndgrid (X 行, Y 列)
        fprintf('  [load csv] %s: %dx%d 域 %.0fx%.0f nm (任意顺序->ndgrid)\n', ...
            fname, numel(ux), numel(uy), max(ux)-min(ux), max(uy)-min(uy));
    else
        S = load(fname);
        if isfield(S,'eps_p')
            ep = double(S.eps_p); ex = double(S.eps_x);
        else
            assert(all(isfield(S,{'eps_xx','eps_yy','eps_xy'})), ...
                'mat 需含 eps_xx/eps_yy/eps_xy 或 eps_p/eps_x');
            ep = double(S.eps_xx)-double(S.eps_yy); ex = 2*double(S.eps_xy);
        end
    end

    [n1,n2] = size(ep);
    if n1==N && n2==N
        eps_p = ep;  eps_x = ex;                          % .mat 已按 ndgrid 存
    else
        xq = linspace(1,n2,N); yq = linspace(1,n1,N); [Xq,Yq] = meshgrid(xq,yq);
        eps_p = interp2(ep, Xq, Yq, 'spline', 0);
        eps_x = interp2(ex, Xq, Yq, 'spline', 0);
        fprintf('  [load] %s %dx%d -> %dx%d (spline)\n', fname, n1, n2, N, N);
    end
    eps_p = eps_p - mean(eps_p(:));  eps_x = eps_x - mean(eps_x(:));
end
