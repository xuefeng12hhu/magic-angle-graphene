%% make_demo_strain_mat.m
% =========================================================================
%  生成演示/回归用应变场 (模拟 COMSOL 弹性求解器的标准导出格式),
%  用于 gl_straingradient_vortex.m 的 mode='file' 测试与本工作 §11 验证.
%
%  导出文件:
%    1) strain_demo_<geom>.mat  (MATLAB .mat, 含 xg, yg, eps_xx, eps_yy, eps_xy)
%    2) comsol_<geom>.csv        (COMSOL 风格文本导出, # x_nm y_nm eps_xx eps_yy eps_xy)
%
%  几何: geom ∈ {'uniax','bubble','wrinkle','edge'}
%    uniax   - 单轴应变梯度 (与 gl_straingradient_vortex 'grad' 模式等价, 用于自检)
%    bubble  - 高斯凸起诱发的双轴径向应变 (各向同性, 无剪切; 伪场环向)
%    wrinkle - 一维正弦波纹 (长波长 L>>xi, 模拟衬底褶皱)
%    edge    - 悬臂梁边缘应变 (线性梯度, 模拟 AFM 推压/接触)
%
%  用法: make_demo_strain_mat;          % 全部四种
%        make_demo_strain_mat('uniax'); % 仅单轴
%        生成的 .mat 可被 load_strain_field() 直接读取
% =========================================================================
function make_demo_strain_mat(geom)
if nargin<1, geom = 'all'; end
close all;
if strcmpi(geom,'all'), geoms = {'uniax','bubble','wrinkle','edge'};
else,                    geoms = {geom}; end

%% ---------- 公共参数 (与 gl_straingradient_vortex 默认一致) ----------
N_export = 1024;                           % 导出网格分辨率 (≥2× 仿真以保证重采样精度)
N_sim    = 128;  xi_nm = 15;               % 与主仿真一致
L_nm     = N_sim*xi_nm;                    % 仿真域 1920 nm
sigma_nm = 150; eps0 = 6e-3;               % 'uniax' 用 (主脚本默认)
nu = 0.16;                                  % 石墨烯面内泊松比

xg = linspace(0, L_nm, N_export);
yg = linspace(0, L_nm, N_export);
% 关键约定: 与 GL 主仿真 (ndgrid) 一致, Y 沿 dim 2 (列); 避免运行期转置开销与符号错位风险
[X, Y] = ndgrid(xg - L_nm/2, yg - L_nm/2);

for g = 1:numel(geoms)
    name = geoms{g};
    switch name
      case 'uniax'                          % 单轴 Y 方向梯度 + 泊松收缩 + 剪切
        G = exp(-(X.^2 + Y.^2)/(2*sigma_nm^2));
        eps_xx =  eps0*(Y./sigma_nm).*G;
        eps_yy = -nu*eps0*(Y./sigma_nm).*G;
        eps_xy =  0.5*eps0*(X./sigma_nm).*G;
      case 'bubble'                         % 高斯凸起 -> 双轴径向, 无剪切
        sigma_b = 300;  h0 = 2;             % 凸起高度 (nm), 半宽 (nm)
        dHdx = -(X./sigma_b.^2).*h0.*exp(-(X.^2+Y.^2)/(2*sigma_b^2));
        dHdy = -(Y./sigma_b.^2).*h0.*exp(-(X.^2+Y.^2)/(2*sigma_b^2));
        eps_xx = dHdx;  eps_yy = dHdy;
        eps_xy = zeros(size(X));
      case 'wrinkle'                        % 一维正弦 (长波长)
        lam = 480;
        eps_xx = eps0*sin(2*pi*X/lam);
        eps_yy = -nu*eps_xx;
        eps_xy = zeros(size(X));
      case 'edge'                           % 边缘/接触局域梯度 (窗化, 周期安全)
        wY = (Y/L_nm).*cos(pi*Y/L_nm).^2;   % 在 Y=±L/2 处严格为 0 -> 无边界跳变
        eps_xx = eps0*wY;
        eps_yy = -nu*eps0*wY;
        eps_xy = zeros(size(X));
      otherwise
        error('未知 geom: %s', name);
    end
    % 减均值使伪场净通量为零 (load_strain_field 也会做, 这里先做以便 CSV 自洽)
    eps_xx = eps_xx - mean(eps_xx(:));
    eps_yy = eps_yy - mean(eps_yy(:));
    eps_xy = eps_xy - mean(eps_xy(:));

    %% .mat 导出 (主用)
    matfile = sprintf('strain_demo_%s.mat', name);
    save(matfile,'xg','yg','eps_xx','eps_yy','eps_xy','-v7');
    fprintf('[%s] %-8s: |eps_xx|max=%.2e  |eps_yy|max=%.2e  |eps_xy|max=%.2e  -> %s\n', ...
        datestr(now,'HH:MM:SS'), name, max(abs(eps_xx(:))), max(abs(eps_yy(:))), max(abs(eps_xy(:))), matfile);

    %% .csv 导出 (COMSOL 风格: "x_nm y_nm eps_xx eps_yy eps_xy")
    %  仅作格式示例, 降采样 step=4 (256²) 以控制体积; .mat 保留全分辨率
    step = 4;
    xs = 1:step:N_export;
    csvfile = sprintf('comsol_%s.csv', name);
    fid = fopen(csvfile,'w');
    fprintf(fid,'%% COMSOL 风格应变导出 (单位 nm / 无量纲应变)\n');
    fprintf(fid,'%% 坐标系: 原点在域中心, X 沿晶格 a1, Y 沿 a2\n');
    fprintf(fid,'%% 点顺序任意 (load_strain_field 由坐标重建网格)\n');
    fprintf(fid,'x_nm,y_nm,eps_xx,eps_yy,eps_xy\n');
    Xc = X(1:step:end, xs); Yc = Y(1:step:end, xs);
    exc = eps_xx(1:step:end, xs); eyc = eps_yy(1:step:end, xs); efc = eps_xy(1:step:end, xs);
    Xcol = Xc(:); Ycol = Yc(:); exx = exc(:); eyy = eyc(:); exy = efc(:);
    fmt = '%.4f,%.4f,%.6e,%.6e,%.6e\n';
    for k = 1:1e3:numel(Xcol)
        idx = k:min(k+999,numel(Xcol));
        fprintf(fid, fmt, [Xcol(idx)'; Ycol(idx)'; exx(idx)'; eyy(idx)'; exy(idx)']);
    end
    fclose(fid);
    d = dir(csvfile);  fprintf('   csv: %s (%.1f KB, %d² 降采样)\n', csvfile, d.bytes/1024, numel(xs));
end
fprintf('\n--- 下一步: 在主脚本里设 mode=''file''; strain_file=''strain_demo_<geom>.mat''\n');
end
