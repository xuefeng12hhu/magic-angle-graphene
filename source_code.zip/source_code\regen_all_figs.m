function regen_all_figs(scripts)
% REGEN_ALL_FIGS  批量重跑出图脚本 (统一出版风格 300 dpi), 每脚本独立工作区
%   regen_all_figs({'s1','s2',...})   — 无参默认全部 9 个
if nargin < 1
    scripts = {'gl_pseudofield_vortex','gl_straingradient_vortex','gl_sweep_gradient', ...
               'gl_fig5_compare','bdg_ldos','bdg_moire_ldos','bm_tc_dome', ...
               'gl_phase_diagram','verify_comsol_backsub'};
end
for i = 1:numel(scripts)
    fprintf('\n========== [%s] %s ==========\n', datestr(now,'HH:MM:SS'), scripts{i});
    t0 = tic;  ok = true;
    try
        run_one(scripts{i});
    catch ME
        ok = false;
        fprintf('ERROR in %s: %s\n', scripts{i}, ME.message);
    end
    if ok, st = 'OK'; else, st = 'FAIL'; end
    fprintf('========== [%s] %s %s (%.1f s) ==========\n', datestr(now,'HH:MM:SS'), ...
        scripts{i}, st, toc(t0));
end
end
function run_one(s) %#ok<INUSD>
% 子函数工作区隔离: 脚本内的 clear 只清掉本工作区, 不影响驱动循环
try
    run([s '.m']);
catch ME
    rethrow(ME);
end
end
