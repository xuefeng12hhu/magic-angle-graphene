function [psi, ene, wmap] = relax_gl(N, Ux, Uy, dt, nStp, psi0)
% GL 梯度流松弛 (带 Peierls 替换 Ux, Uy); 返回最终 ψ, 能量, 涡旋图
    if nargin < 6
        psi = 0.05*(randn(N,N)+1i*randn(N,N));
    else
        psi = psi0;
    end
    for it = 1:nStp
        lap = conj(Ux).*psi([2:N 1],:) + Ux([N 1:N-1],:).*psi([N 1:N-1],:) ...
            + conj(Uy).*psi(:,[2:N 1]) + Uy(:,[N 1:N-1]).*psi(:,[N 1:N-1]) - 4*psi;
        psi = psi + dt*(lap + (1-abs(psi).^2).*psi);
    end
    kx = abs(psi([2:N 1],:) - Ux.*psi).^2;
    ky = abs(psi(:,[2:N 1]) - Uy.*psi).^2;
    ene = sum(kx(:)) + sum(ky(:)) + sum(-abs(psi(:)).^2 + 0.5*abs(psi(:)).^4);
    wmap = vortex_map(psi, Ux, Uy);
end
