function save_paper_figs(figs, name, finalIn, dpi)
% SAVE_PAPER_FIGS  统一风格 + 按"最终印刷尺寸"输出位图
%   save_paper_figs(figs, name)              — 旧行为: 图窗尺寸即输出尺寸, 300 dpi
%   save_paper_figs(figs, name, [W H])       — 输出纸张固定为 W x H 英寸 (600 dpi)
%
% 为什么需要 finalIn:
%   位图在 LaTeX 里按 width=... 整体缩放, 图内字号随之等比缩小. 旧版 Fig.2/Fig.3
%   的画布宽 11.98 in、字号 11 pt, 印到 0.68\textwidth = 4.82 in 时缩到 0.40 倍,
%   版面字号只剩 ~4.4 pt (Fig.1 的画布 8.43 in、字号 11 pt, 缩 0.74 倍 -> ~8 pt).
%   正确做法: 画布 1:1 取最终印刷尺寸, 直接写版面所需字号 (8 pt), 300+ dpi 输出.
%   (注意 MATLAB print 的 PaperPosition 只缩放几何, 不缩放字号, 故不能靠"大画布
%    小纸面"来偷缩放.)
if nargin < 1 || isempty(figs), figs = findall(0, 'Type', 'figure'); end
if nargin < 2 || isempty(name), name = mfilename('caller'); end
if nargin < 3, finalIn = []; end
if nargin < 4 || isempty(dpi)
    if isempty(finalIn), dpi = 300; else, dpi = 600; end
end

for k = 1:numel(figs)
    f = figs(k);
    if ~ishandle(f), continue; end
    if isempty(finalIn)
        set_paper_style(f);                         % 旧行为: 字号统一 11 pt, 300 dpi
    else
        set(f, 'Units', 'inches');
        p = get(f, 'Position');
        sc = p(3)/finalIn(1);                       % 画布/印刷尺寸之比 (1:1 时为 1)
        set(f, 'PaperUnits', 'inches', 'PaperSize', finalIn(:)', ...
               'PaperPosition', [0 0 finalIn(:)'], 'PaperPositionMode', 'manual');
        set_paper_style(f, [], sc);                 % 保留脚本里显式设定的字号
    end
    print(f, sprintf('%s_fig%d.png', name, k), '-dpng', sprintf('-r%d', round(dpi)));
end
if isempty(finalIn)
    fprintf('已保存 %d 张图 (Times New Roman / LW 0.75 / %d dpi): %s_fig*.png\n', ...
        numel(figs), round(dpi), name);
else
    fprintf('已保存 %d 张图 (Times New Roman / 印刷尺寸 %.2f x %.2f in / %d dpi): %s_fig*.png\n', ...
        numel(figs), finalIn(1), finalIn(2), round(dpi), name);
end
end
