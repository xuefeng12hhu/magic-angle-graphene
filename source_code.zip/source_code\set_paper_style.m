function set_paper_style(fig, fontSize, sc)
% SET_PAPER_STYLE  统一出版风格: Times New Roman, 刻度外向, box on, 白底.
%   set_paper_style(fig)             — 兼容旧调用: 字号统一为 11 pt, 线宽按 1x
%   set_paper_style(fig, [])         — 只改字体/线宽, 保留各对象已有字号
%   set_paper_style(fig, [], sc)     — 同上, 但线宽整体乘以 sc
%   set_paper_style(fig, 16)         — 强制全部字号为 16 pt
%
% 说明 (R2018b):
%   - 字体统一为 Times New Roman (与正文新罗马体一致); 物理量符号的斜体
%     由各 text 对象的 Interpreter='tex' + '\it...\rm' 控制, 本函数不干预.
%   - 版面按"画布 = sc x 印刷尺寸"布置时, 线宽需同步乘 sc, 打印缩回后
%     才是 0.75 pt / 1.2 pt 的实际线宽 (见 save_paper_figs).
if nargin < 1 || isempty(fig), fig = gcf; end
if ~ishandle(fig), return; end
if nargin < 2, fontSize = 11; end          % 旧行为: 强制 11 pt
if nargin < 3 || isempty(sc), sc = 1; end

try set(fig, 'Color', 'w'); end %#ok

% ---- 字体 ----
for h = reshape(findall(fig, '-property', 'FontName'), 1, [])
    try set(h, 'FontName', 'Times New Roman'); end %#ok
end

% ---- 字号 (fontSize 为空则保留各对象自身设置) ----
if ~isempty(fontSize)
    for h = reshape(findall(fig, '-property', 'FontSize'), 1, [])
        try set(h, 'FontSize', fontSize); end %#ok
    end
end

% ---- 坐标轴框架 ----
for a = reshape(findall(fig, 'Type', 'axes'), 1, [])
    try set(a, 'LineWidth', 0.75*sc, 'TickDir', 'out', 'Box', 'on'); end %#ok
end

% ---- 数据线宽 (只提升过细的默认线, 不压细显式加粗的线) ----
for l = reshape(findall(fig, 'Type', 'line'), 1, [])
    try
        if get(l, 'LineWidth') < 1.2*sc, set(l, 'LineWidth', 1.2*sc); end
    end %#ok
end
end
