%% verify_comsol_backsub.m —— §11 弹性回代 (COMSOL) 端到端验证
% 工作流:
%   1) 跑 make_demo_strain_mat.m 生成 4 种典型几何的 .mat + .csv
%   2) 交叉检验 'uniax': mode='file' (spline 重采样 1024->512) vs 解析式 -> B_s 场应一致
%   3) 四种几何端到端: B_s 场形貌, 净通量, GL 涡旋响应
%   4) CSV 格式读取自检 (小文件, 快速)
% 注意: spline 插值 1024->512 较慢 (~2 min/几何), 每个文件只加载一次并复用
clear; clc; close all;

fprintf('===== §11 弹性回代端到端验证 =====\n\n');

%% ---------- 公共参数 ----------
N_base = 128;  xi_nm = 15;  hfac = 0.25;
N = round(N_base/hfac);
sigma_nm = 150;  eps0 = 6e-3;  nu = 0.16;
dt = 0.1;  nStp = 8000;                       % 短时松弛, 节省机时
beta = 3; a_cc = 0.142;  C = beta/(2*a_cc)*xi_nm;
Bc2 = 2.07e-15/(2*pi*(xi_nm*1e-9)^2);

%% ---------- 1) 生成 4 种几何 ----------
fprintf('--- 1) 生成 4 种几何的 .mat + .csv ---\n');
make_demo_strain_mat('all');
fprintf('\n');

%% ---------- 2) 一次性加载 4 个应变场 (ndgrid 约定) ----------
geoms = {'uniax','bubble','wrinkle','edge'};
EP = cell(1,4);  EX = cell(1,4);
for g = 1:4
    [EP{g}, EX{g}] = load_strain_field(sprintf('strain_demo_%s.mat', geoms{g}), N, xi_nm);
end

%% ---------- 3) 交叉检验: uniax (file) vs 解析式 ----------
fprintf('--- 2) 交叉检验: uniax (file) vs 解析式 ---\n');
% (a) file 路径 (含 spline 重采样 1024->512)
ax_f = C*EP{1};  ay_f = -C*EX{1};
Bfile = curlz(ax_f, ay_f)/hfac * 2.07e-15/(pi*(xi_nm*1e-9)^2);
% (b) 解析式 (与导出端逐分量一致: eps_p=(1+ν)ε₀(Y/σ)G, eps_x=ε₀(X/σ)G)
h_nm = xi_nm*hfac;  sigma = sigma_nm/h_nm;
idx = 0:N-1; [Xg,Yg] = ndgrid(idx,idx); Xg = Xg-N/2; Yg = Yg-N/2;
G = @(x,y) exp(-(x.^2+y.^2)/(2*sigma^2));
ax_a = C*(1+nu)*eps0*(Yg./sigma).*G(Xg,Yg);
ay_a = -C*eps0*(Xg./sigma).*G(Xg,Yg);
Bgrad = curlz(ax_a, ay_a)/hfac * 2.07e-15/(pi*(xi_nm*1e-9)^2);
% (c) GL 响应
st_f = gl_stats(N, ax_f, ay_f, hfac, dt, nStp, xi_nm);
st_a = gl_stats(N, ax_a, ay_a, hfac, dt, nStp, xi_nm);
fprintf('  file: |Bs|max=%.1f mT, 净通量=%+.3f, 涡旋+/-%d/%d\n', ...
    st_f.Bsmax*1e3, st_f.net_flux, st_f.npos, st_f.nneg);
fprintf('  ana : |Bs|max=%.1f mT, 净通量=%+.3f, 涡旋+/-%d/%d\n', ...
    st_a.Bsmax*1e3, st_a.net_flux, st_a.npos, st_a.nneg);
rm = round(0.04*N);
relerr = norm(Bfile(rm+1:end-rm,rm+1:end-rm)-Bgrad(rm+1:end-rm,rm+1:end-rm)) ...
       / norm(Bgrad(rm+1:end-rm,rm+1:end-rm));
fprintf('  → 相对 L2 差 (B_s 场): %.4f  (阈值 0.1)\n', relerr);
assert(relerr < 0.1, 'file/analytic B_s 差异过大: %.3f', relerr);
fprintf('  ✓ 交叉检验通过\n\n');

%% ---------- 4) 四种几何端到端 ----------
fprintf('--- 3) 四种几何: B_s 场 + GL 涡旋响应 ---\n');
Bs_all = cell(1,4);
for g = 1:4
    ax = C*EP{g};  ay = -C*EX{g};
    Bs_all{g} = curlz(ax,ay)/hfac * 2.07e-15/(pi*(xi_nm*1e-9)^2);
    st = gl_stats(N, ax, ay, hfac, dt, nStp, xi_nm);
    fprintf('  %-8s: |Bs|max=%5.1f mT  B_s/B_c2=%.3f  净通量=%+5.2f  N+/N-=%3d/%3d\n', ...
        geoms{g}, st.Bsmax*1e3, st.ratio, st.net_flux, st.npos, st.nneg);
end
fprintf('\n');

%% ---------- 5) CSV 格式读取自检 (小文件, 快) ----------
fprintf('--- 4) CSV 格式自检 ---\n');
n8 = 8; L8 = N_base*xi_nm; x8 = linspace(-L8/2, L8/2, n8);
fid = fopen('comsol_test8.csv','w');
fprintf(fid,'%% COMSOL 风格测试\n%% 注释行 2\n');
fprintf(fid,'x_nm,y_nm,eps_xx,eps_yy,eps_xy\n');
[X8, Y8] = meshgrid(x8, x8);          % CSV 按 meshgrid 行序存储
G8 = exp(-(X8.^2+Y8.^2)/(2*sigma_nm^2));
for i = 1:n8, for j = 1:n8
    fprintf(fid,'%.4f,%.4f,%.6e,%.6e,%.6e\n', X8(i,j), Y8(i,j), ...
        eps0*(Y8(i,j)/sigma_nm)*G8(i,j), -nu*eps0*(Y8(i,j)/sigma_nm)*G8(i,j), ...
        0.5*eps0*(X8(i,j)/sigma_nm)*G8(i,j));
end, end
fclose(fid);
[ep_csv, ex_csv] = load_strain_field('comsol_test8.csv', n8, xi_nm);
% 期望: ndgrid 排列 (= meshgrid 结果的转置)
ep_ref = (1+nu)*eps0*(Y8.')./sigma_nm .* G8.';
ex_ref = eps0*(X8.')./sigma_nm .* G8.';
err_ep = max(abs(ep_csv(:)-ep_ref(:)));  err_ex = max(abs(ex_csv(:)-ex_ref(:)));
fprintf('  CSV 解析: max|Δeps_p|=%.2e  max|Δeps_x|=%.2e  (应 < 1e-8, %.6e 格式截断底 ~1e-9)\n', err_ep, err_ex);
assert(err_ep < 1e-8 && err_ex < 1e-8, 'CSV 解析与期望不一致');
fprintf('  ✓ CSV (meshgrid->ndgrid) 读取正确\n\n');

%% ---------- 6) 汇总图 ----------
figure('Color','w','Position',[40 40 1300 720]);
for g = 1:4
    subplot(2,4,g);
    imagesc(Bs_all{g}*1e3); axis image off; colorbar;
    title(sprintf('(%s) B_s [mT]', geoms{g}));
    subplot(2,4,g+4);
    imagesc(EP{g}*1e3); axis image off; colorbar;
    title(sprintf('\\epsilon_p \\times 10^{-3} (export)'));
end
save_paper_figs(gcf, 'verify_comsol_backsub');
fprintf('已保存 verify_comsol_backsub_fig1.png\n');
fprintf('\n===== §11 验证全部通过 =====\n');

% ======================= 辅助函数 =======================
function st = gl_stats(N, ax, ay, hfac, dt, nStp, xi_nm)
    bs = curlz(ax,ay)/hfac;
    rm = round(0.04*N);
    Bsmax = max(max(abs(bs(rm+1:end-rm, rm+1:end-rm)))) * 2.07e-15/(pi*(xi_nm*1e-9)^2);
    netf = sum(bs(:))/(2*pi);
    [~, ~, wmap] = relax_gl(N, exp(-2i*ax), exp(-2i*ay), dt, nStp);
    Bc2 = 2.07e-15/(2*pi*(xi_nm*1e-9)^2);
    st.Bsmax = Bsmax; st.net_flux = netf;
    st.npos = sum(wmap(:)>0); st.nneg = sum(wmap(:)<0);
    st.ratio = Bsmax/Bc2;
end
