function w = vortex_map(psi, Ux, Uy)
% 涡旋图: 包含 Peierls 相位修正
    N = size(psi,1);
    p1=psi; p2=psi([2:N 1],:); p3=psi([2:N 1],[2:N 1]); p4=psi(:,[2:N 1]);
    loop = angle(p2.*conj(p1)) + angle(p3.*conj(p2)) + angle(p4.*conj(p3)) + angle(p1.*conj(p4));
    ph = angle(Ux) + angle(Uy([2:N 1],:)) - angle(Ux(:,[2:N 1])) - angle(Uy);
    w = round((loop + ph)/(2*pi));
end
